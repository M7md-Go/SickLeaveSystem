using System;
using System.Drawing;
using System.Windows.Forms;

namespace SickLeaveSystem
{
    public partial class frmSplash : Form
    {
        private Timer timer;

        public frmSplash()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.FromArgb(7, 11, 24);
            this.Size = new Size(500, 300);
            SetupControls();
            timer = new Timer();
            timer.Interval = 3000;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void SetupControls()
        {
            // عنوان التطبيق
            Label lblTitle = new Label();
            lblTitle.Text = "نظام إدارة الإجازات المرضية";
            lblTitle.Font = new Font("Cairo", 20, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(200, 168, 75);
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblTitle.Dock = DockStyle.Top;
            lblTitle.Height = 80;
            lblTitle.Padding = new Padding(0, 40, 0, 0);
            this.Controls.Add(lblTitle);

            // الشعار
            Label lblLogo = new Label();
            lblLogo.Text = "🏥";
            lblLogo.Font = new Font("Segoe UI", 48);
            lblLogo.ForeColor = Color.WhiteSmoke;
            lblLogo.TextAlign = ContentAlignment.MiddleCenter;
            lblLogo.Dock = DockStyle.Fill;
            lblLogo.Height = 100;
            this.Controls.Add(lblLogo);

            // شريط التحميل
            ProgressBar pb = new ProgressBar();
            pb.Style = ProgressBarStyle.Marquee;
            pb.Dock = DockStyle.Bottom;
            pb.Height = 5;
            pb.ForeColor = Color.FromArgb(200, 168, 75);
            this.Controls.Add(pb);

            // نص التحميل
            Label lblStatus = new Label();
            lblStatus.Text = "جاري تهيئة النظام...";
            lblStatus.Font = new Font("Cairo", 9);
            lblStatus.ForeColor = Color.FromArgb(155, 168, 208);
            lblStatus.TextAlign = ContentAlignment.MiddleCenter;
            lblStatus.Dock = DockStyle.Bottom;
            lblStatus.Height = 30;
            this.Controls.Add(lblStatus);
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}