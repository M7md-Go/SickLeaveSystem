using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmReports : Form
    {
        private ComboBox cmbReportType;
        private Panel filterPanel;
        private DataGridView dgvResult;
        private Button btnGenerate, btnExportExcel, btnExportCSV, btnPrint;
        private Label lblTitle;

        public frmReports()
        {
            InitializeComponent();
            LoadReportTypes();
        }

        private void InitializeComponent()
        {
            this.Text = "التقارير";
            this.Size = new Size(1100, 650);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // اللوحة العلوية
            Panel topPanel = new Panel();
            topPanel.Dock = DockStyle.Top;
            topPanel.Height = 120;
            topPanel.BackColor = Color.FromArgb(13, 24, 40);
            topPanel.Padding = new Padding(10);

            Label lblType = new Label();
            lblType.Text = "نوع التقرير:";
            lblType.ForeColor = Color.White;
            lblType.Location = new Point(20, 20);
            lblType.AutoSize = true;

            cmbReportType = new ComboBox();
            cmbReportType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbReportType.Location = new Point(130, 18);
            cmbReportType.Width = 200;
            cmbReportType.BackColor = Color.FromArgb(22, 30, 50);
            cmbReportType.ForeColor = Color.White;
            cmbReportType.SelectedIndexChanged += CmbReportType_SelectedIndexChanged;

            filterPanel = new Panel();
            filterPanel.Location = new Point(20, 55);
            filterPanel.Size = new Size(600, 50);
            filterPanel.BackColor = Color.Transparent;

            btnGenerate = new Button();
            btnGenerate.Text = "📊 إنشاء التقرير";
            btnGenerate.FlatStyle = FlatStyle.Flat;
            btnGenerate.BackColor = Color.FromArgb(200, 168, 75);
            btnGenerate.ForeColor = Color.Black;
            btnGenerate.Size = new Size(130, 35);
            btnGenerate.Location = new Point(650, 60);
            btnGenerate.Click += BtnGenerate_Click;

            topPanel.Controls.Add(lblType);
            topPanel.Controls.Add(cmbReportType);
            topPanel.Controls.Add(filterPanel);
            topPanel.Controls.Add(btnGenerate);

            // شريط الأزرار السفلية
            Panel bottomPanel = new Panel();
            bottomPanel.Dock = DockStyle.Bottom;
            bottomPanel.Height = 50;
            bottomPanel.BackColor = Color.FromArgb(13, 24, 40);

            btnExportExcel = new Button();
            btnExportExcel.Text = "📊 Excel";
            btnExportExcel.FlatStyle = FlatStyle.Flat;
            btnExportExcel.BackColor = Color.FromArgb(16, 201, 127);
            btnExportExcel.ForeColor = Color.Black;
            btnExportExcel.Size = new Size(100, 35);
            btnExportExcel.Location = new Point(10, 8);
            btnExportExcel.Click += BtnExportExcel_Click;

            btnExportCSV = new Button();
            btnExportCSV.Text = "📄 CSV";
            btnExportCSV.FlatStyle = FlatStyle.Flat;
            btnExportCSV.BackColor = Color.FromArgb(167, 139, 250);
            btnExportCSV.ForeColor = Color.White;
            btnExportCSV.Size = new Size(100, 35);
            btnExportCSV.Location = new Point(120, 8);
            btnExportCSV.Click += BtnExportCSV_Click;

            btnPrint = new Button();
            btnPrint.Text = "🖨️ طباعة";
            btnPrint.FlatStyle = FlatStyle.Flat;
            btnPrint.BackColor = Color.FromArgb(245, 158, 11);
            btnPrint.ForeColor = Color.Black;
            btnPrint.Size = new Size(100, 35);
            btnPrint.Location = new Point(230, 8);
            btnPrint.Click += BtnPrint_Click;

            lblTitle = new Label();
            lblTitle.Text = "نتائج التقرير";
            lblTitle.ForeColor = Color.White;
            lblTitle.Font = new Font("Cairo", 12, FontStyle.Bold);
            lblTitle.Location = new Point(450, 12);
            lblTitle.AutoSize = true;

            bottomPanel.Controls.Add(btnExportExcel);
            bottomPanel.Controls.Add(btnExportCSV);
            bottomPanel.Controls.Add(btnPrint);
            bottomPanel.Controls.Add(lblTitle);

            // DataGridView
            dgvResult = new DataGridView();
            dgvResult.Dock = DockStyle.Fill;
            dgvResult.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvResult.ForeColor = Color.White;
            dgvResult.GridColor = Color.FromArgb(30, 45, 82);
            dgvResult.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvResult.RightToLeft = RightToLeft.Yes;
            dgvResult.ReadOnly = true;
            dgvResult.RowHeadersVisible = false;
            dgvResult.AllowUserToAddRows = false;

            this.Controls.Add(dgvResult);
            this.Controls.Add(bottomPanel);
            this.Controls.Add(topPanel);
        }

        private void LoadReportTypes()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Value");
            dt.Columns.Add("Text");
            dt.Rows.Add("monthly", "تقرير شهري");
            dt.Rows.Add("employee", "تقرير إجازات موظف");
            dt.Rows.Add("department", "تقرير حسب القسم");
            dt.Rows.Add("decision", "تقرير القرار 259");
            dt.Rows.Add("status", "تقرير حسب الحالة");
            dt.Rows.Add("annual", "تقرير سنوي");
            dt.Rows.Add("top_employees", "أكثر الموظفين إجازات");
            cmbReportType.DataSource = dt;
            cmbReportType.DisplayMember = "Text";
            cmbReportType.ValueMember = "Value";
            cmbReportType.SelectedIndex = 0;
        }

        private void CmbReportType_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterPanel.Controls.Clear();
            string type = cmbReportType.SelectedValue.ToString();
            switch (type)
            {
                case "monthly":
                    AddMonthYearFilter();
                    break;
                case "employee":
                    AddEmployeeFilter();
                    break;
                case "department":
                    AddDepartmentFilter();
                    break;
                case "decision":
                    AddDecisionFilter();
                    break;
                case "status":
                    AddStatusFilter();
                    break;
                case "annual":
                    AddYearFilter();
                    break;
                case "top_employees":
                    AddTopCountFilter();
                    break;
            }
        }

        private void AddMonthYearFilter()
        {
            ComboBox cmbMonth = new ComboBox();
            cmbMonth.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMonth.Items.AddRange(new string[] { "1 - يناير", "2 - فبراير", "3 - مارس", "4 - أبريل", "5 - مايو", "6 - يونيو", "7 - يوليو", "8 - أغسطس", "9 - سبتمبر", "10 - أكتوبر", "11 - نوفمبر", "12 - ديسمبر" });
            cmbMonth.SelectedIndex = DateTime.Now.Month - 1;
            cmbMonth.Tag = "month";

            NumericUpDown numYear = new NumericUpDown();
            numYear.Minimum = 2000;
            numYear.Maximum = DateTime.Now.Year + 1;
            numYear.Value = DateTime.Now.Year;
            numYear.Width = 80;
            numYear.Tag = "year";

            filterPanel.Controls.Add(cmbMonth);
            filterPanel.Controls.Add(numYear);
            cmbMonth.Location = new Point(0, 5);
            numYear.Location = new Point(120, 5);
        }

        private void AddEmployeeFilter()
        {
            TextBox txtEmp = new TextBox();
            txtEmp.Width = 200;
            txtEmp.BackColor = Color.FromArgb(22, 30, 50);
            txtEmp.ForeColor = Color.White;
            txtEmp.PlaceholderText = "اسم الموظف أو الكود";
            txtEmp.Tag = "emp";
            filterPanel.Controls.Add(txtEmp);
            txtEmp.Location = new Point(0, 5);
        }

        private void AddDepartmentFilter()
        {
            ComboBox cmbDept = new ComboBox();
            cmbDept.DropDownStyle = ComboBoxStyle.DropDownList;
            DataTable dt = BusinessLogic.GetAllDepartments();
            dt.Rows.InsertAt(dt.NewRow(), 0);
            dt.Rows[0]["ID"] = 0;
            dt.Rows[0]["Name"] = "الكل";
            cmbDept.DataSource = dt;
            cmbDept.DisplayMember = "Name";
            cmbDept.ValueMember = "ID";
            cmbDept.Tag = "dept";
            cmbDept.Width = 200;
            filterPanel.Controls.Add(cmbDept);
            cmbDept.Location = new Point(0, 5);
        }

        private void AddDecisionFilter()
        {
            TextBox txtDecision = new TextBox();
            txtDecision.Width = 200;
            txtDecision.BackColor = Color.FromArgb(22, 30, 50);
            txtDecision.ForeColor = Color.White;
            txtDecision.PlaceholderText = "رقم القرار (اختياري)";
            txtDecision.Tag = "decision";
            filterPanel.Controls.Add(txtDecision);
            txtDecision.Location = new Point(0, 5);
        }

        private void AddStatusFilter()
        {
            ComboBox cmbStatus = new ComboBox();
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.Items.AddRange(new string[] { "الكل", "تحت المراجعة", "معتمدة", "مرفوضة", "منتهية" });
            cmbStatus.SelectedIndex = 0;
            cmbStatus.Tag = "status";
            cmbStatus.Width = 150;
            filterPanel.Controls.Add(cmbStatus);
            cmbStatus.Location = new Point(0, 5);
        }

        private void AddYearFilter()
        {
            NumericUpDown numYear = new NumericUpDown();
            numYear.Minimum = 2000;
            numYear.Maximum = DateTime.Now.Year;
            numYear.Value = DateTime.Now.Year;
            numYear.Tag = "year";
            filterPanel.Controls.Add(numYear);
            numYear.Location = new Point(0, 5);
        }

        private void AddTopCountFilter()
        {
            NumericUpDown numCount = new NumericUpDown();
            numCount.Minimum = 1;
            numCount.Maximum = 50;
            numCount.Value = 10;
            numCount.Tag = "top";
            filterPanel.Controls.Add(numCount);
            numCount.Location = new Point(0, 5);
            Label lbl = new Label();
            lbl.Text = "أكثر الموظفين إجازات (العدد):";
            lbl.ForeColor = Color.White;
            lbl.Location = new Point(0, -15);
            lbl.AutoSize = true;
            filterPanel.Controls.Add(lbl);
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            string type = cmbReportType.SelectedValue.ToString();
            string query = "";
            DataTable result = null;

            switch (type)
            {
                case "monthly":
                    int month = ((ComboBox)filterPanel.Controls["month"]).SelectedIndex + 1;
                    int year = (int)((NumericUpDown)filterPanel.Controls["year"]).Value;
                    query = $"SELECT EmpName, DepartmentName, DateFrom, DateTo, Days, Diagnosis, DecisionNo, Status FROM SickLeaves WHERE MONTH(DateFrom) = {month} AND YEAR(DateFrom) = {year} ORDER BY DateFrom";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = $"تقرير شهري - {month}/{year}";
                    break;
                case "employee":
                    string empFilter = ((TextBox)filterPanel.Controls["emp"]).Text.Trim();
                    query = $"SELECT EmpName, DepartmentName, DateFrom, DateTo, Days, Diagnosis, DecisionNo, Status FROM SickLeaves WHERE EmpName LIKE '%{empFilter.Replace("'", "''")}%' OR EmpCode LIKE '%{empFilter.Replace("'", "''")}%' ORDER BY DateFrom DESC";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = "تقرير إجازات موظف" + (string.IsNullOrEmpty(empFilter) ? "" : $" - {empFilter}");
                    break;
                case "department":
                    int deptId = Convert.ToInt32(((ComboBox)filterPanel.Controls["dept"]).SelectedValue);
                    if (deptId > 0)
                    {
                        DataTable deptDt = DatabaseManager.ExecuteQuery("SELECT Name FROM Departments WHERE ID=?", DatabaseManager.CreateParameter("@id", deptId));
                        string deptName = deptDt.Rows[0]["Name"].ToString();
                        query = $"SELECT EmpName, DateFrom, DateTo, Days, Diagnosis, DecisionNo, Status FROM SickLeaves WHERE DepartmentID = {deptId} ORDER BY DateFrom DESC";
                        result = DatabaseManager.ExecuteQuery(query);
                        lblTitle.Text = $"تقرير قسم {deptName}";
                    }
                    else
                    {
                        query = "SELECT DepartmentName, COUNT(*) AS TotalLeaves, SUM(Days) AS TotalDays FROM SickLeaves GROUP BY DepartmentName ORDER BY TotalLeaves DESC";
                        result = DatabaseManager.ExecuteQuery(query);
                        lblTitle.Text = "تقرير الأقسام (إجمالي الإجازات)";
                    }
                    break;
                case "decision":
                    string decision = ((TextBox)filterPanel.Controls["decision"]).Text.Trim();
                    query = $"SELECT EmpName, DepartmentName, DateFrom, DateTo, Days, DecisionNo, Status FROM SickLeaves WHERE DecisionNo LIKE '%{decision.Replace("'", "''")}%' ORDER BY DateFrom DESC";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = "تقرير القرار 259" + (string.IsNullOrEmpty(decision) ? "" : $" - {decision}");
                    break;
                case "status":
                    string statusText = ((ComboBox)filterPanel.Controls["status"]).SelectedItem.ToString();
                    string statusVal = "";
                    if (statusText == "تحت المراجعة") statusVal = Constants.SickLeaveStatusReview;
                    else if (statusText == "معتمدة") statusVal = Constants.SickLeaveStatusApproved;
                    else if (statusText == "مرفوضة") statusVal = Constants.SickLeaveStatusRejected;
                    else if (statusText == "منتهية") statusVal = Constants.SickLeaveStatusExpired;
                    if (!string.IsNullOrEmpty(statusVal))
                        query = $"SELECT EmpName, DepartmentName, DateFrom, DateTo, Days, Diagnosis, DecisionNo FROM SickLeaves WHERE Status = '{statusVal}' ORDER BY DateFrom DESC";
                    else
                        query = "SELECT Status, COUNT(*) AS TotalLeaves, SUM(Days) AS TotalDays FROM SickLeaves GROUP BY Status";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = "تقرير حسب الحالة" + (string.IsNullOrEmpty(statusVal) ? "" : $" - {statusText}");
                    break;
                case "annual":
                    int year2 = (int)((NumericUpDown)filterPanel.Controls["year"]).Value;
                    query = $"SELECT EmpName, DepartmentName, DateFrom, DateTo, Days, Diagnosis, DecisionNo, Status FROM SickLeaves WHERE YEAR(DateFrom) = {year2} ORDER BY DateFrom";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = $"تقرير سنوي - {year2}";
                    break;
                case "top_employees":
                    int top = (int)((NumericUpDown)filterPanel.Controls["top"]).Value;
                    query = $"SELECT EmpName, COUNT(*) AS TotalLeaves, SUM(Days) AS TotalDays FROM SickLeaves GROUP BY EmpName ORDER BY TotalLeaves DESC LIMIT {top}";
                    result = DatabaseManager.ExecuteQuery(query);
                    lblTitle.Text = $"أكثر {top} موظف إجازات";
                    break;
            }

            if (result != null && result.Rows.Count > 0)
            {
                dgvResult.DataSource = result;
                dgvResult.AutoResizeColumns();
            }
            else
            {
                dgvResult.DataSource = null;
                MessageBox.Show("لا توجد بيانات تطابق معايير التقرير.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            if (dgvResult.DataSource == null) return;
            DataTable dt = dgvResult.DataSource as DataTable;
            if (dt != null && dt.Rows.Count > 0)
                ExportHelper.ExportToExcel(dt, $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.xls");
            else
                MessageBox.Show("لا توجد بيانات للتصدير.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnExportCSV_Click(object sender, EventArgs e)
        {
            if (dgvResult.DataSource == null) return;
            DataTable dt = dgvResult.DataSource as DataTable;
            if (dt != null && dt.Rows.Count > 0)
                ExportHelper.ExportToCSV(dt, $"Report_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            else
                MessageBox.Show("لا توجد بيانات للتصدير.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            if (dgvResult.DataSource == null) return;
            DataTable dt = dgvResult.DataSource as DataTable;
            if (dt != null && dt.Rows.Count > 0)
                ReportHelper.PrintPreview(dt, lblTitle.Text);
            else
                MessageBox.Show("لا توجد بيانات للطباعة.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}