using System;
using System.Data;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // التحقق من وجود قاعدة البيانات وإنشاء الجداول تلقائيًا
            EnsureDatabase();

            // عرض شاشة البداية
            using (frmSplash splash = new frmSplash())
            {
                if (splash.ShowDialog() != DialogResult.OK)
                    return;
            }

            // التحقق من وجود مستخدمين
            DataTable users = DatabaseManager.ExecuteQuery("SELECT COUNT(*) FROM Users");
            int userCount = Convert.ToInt32(users.Rows[0][0]);

            if (userCount == 0)
            {
                // إنشاء مستخدم المشرف الأول تلقائيًا
                string defaultUsername = "admin";
                string defaultPassword = "admin123";
                string salt = SecurityHelper.GenerateSalt();
                string hash = SecurityHelper.HashPassword(defaultPassword, salt);
                DatabaseManager.ExecuteNonQuery(
                    "INSERT INTO Users (Username, PasswordHash, PasswordSalt, Role, IsActive, CreatedAt) VALUES (?, ?, ?, ?, ?, NOW())",
                    DatabaseManager.CreateParameter("@user", defaultUsername),
                    DatabaseManager.CreateParameter("@hash", hash),
                    DatabaseManager.CreateParameter("@salt", salt),
                    DatabaseManager.CreateParameter("@role", Constants.RoleAdmin),
                    DatabaseManager.CreateParameter("@active", true));
                MessageBox.Show($"تم إنشاء حساب المشرف العام تلقائيًا.\nاسم المستخدم: {defaultUsername}\nكلمة المرور: {defaultPassword}\nيرجى تغيير كلمة المرور بعد تسجيل الدخول.", "تهيئة أولية", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // نافذة تسجيل الدخول
            using (frmLogin login = new frmLogin())
            {
                if (login.ShowDialog() != DialogResult.OK)
                    return;
            }

            // النافذة الرئيسية
            Application.Run(new frmMain());
        }

        private static void EnsureDatabase()
        {
            // فقط للتأكد من أن الاتصال يعمل والجداول موجودة (تم إنشاؤها مسبقًا)
            // إذا كان هناك خطأ، سنقوم بإنشاء قاعدة البيانات من الصفر (اختياري)
            try
            {
                DatabaseManager.ExecuteQuery("SELECT COUNT(*) FROM Employees");
            }
            catch
            {
                MessageBox.Show("خطأ في الاتصال بقاعدة البيانات. تأكد من وجود ملف SickLeaveDB.mdb في مجلد Database.", "خطأ فادح", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(1);
            }
        }
    }
}