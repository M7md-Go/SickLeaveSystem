namespace SickLeaveSystem
{
    partial class frmLogin
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSub;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkShowPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.chkShowPassword = new System.Windows.Forms.CheckBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Cairo", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(120, 20);
            this.lblTitle.Size = new System.Drawing.Size(200, 38);
            this.lblTitle.Text = "نظام الإجازات المرضية";
            // lblSub
            this.lblSub.AutoSize = true;
            this.lblSub.Font = new System.Drawing.Font("Cairo", 9F);
            this.lblSub.Location = new System.Drawing.Point(160, 65);
            this.lblSub.Text = "تسجيل الدخول إلى النظام";
            // lblUsername
            this.lblUsername.AutoSize = true;
            this.lblUsername.Location = new System.Drawing.Point(250, 110);
            this.lblUsername.Size = new System.Drawing.Size(80, 18);
            this.lblUsername.Text = "اسم المستخدم:";
            // txtUsername
            this.txtUsername.Location = new System.Drawing.Point(50, 108);
            this.txtUsername.Size = new System.Drawing.Size(190, 23);
            // lblPassword
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(260, 150);
            this.lblPassword.Size = new System.Drawing.Size(70, 18);
            this.lblPassword.Text = "كلمة المرور:";
            // txtPassword
            this.txtPassword.Location = new System.Drawing.Point(50, 148);
            this.txtPassword.Size = new System.Drawing.Size(190, 23);
            this.txtPassword.PasswordChar = '*';
            // chkShowPassword
            this.chkShowPassword.AutoSize = true;
            this.chkShowPassword.Location = new System.Drawing.Point(50, 180);
            this.chkShowPassword.Size = new System.Drawing.Size(110, 22);
            this.chkShowPassword.Text = "عرض كلمة المرور";
            // btnLogin
            this.btnLogin.Location = new System.Drawing.Point(160, 220);
            this.btnLogin.Size = new System.Drawing.Size(85, 30);
            this.btnLogin.Text = "دخول";
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // btnCancel
            this.btnCancel.Location = new System.Drawing.Point(60, 220);
            this.btnCancel.Size = new System.Drawing.Size(85, 30);
            this.btnCancel.Text = "إلغاء";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // Form
            this.ClientSize = new System.Drawing.Size(400, 280);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.chkShowPassword);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnCancel);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}