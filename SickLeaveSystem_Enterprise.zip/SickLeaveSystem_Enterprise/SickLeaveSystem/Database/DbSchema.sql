-- 1. جدول الأقسام
CREATE TABLE Departments 
(
    ID AUTOINCREMENT CONSTRAINT PK_Departments PRIMARY KEY,
    Name TEXT(100) NOT NULL CONSTRAINT UQ_DepartmentName UNIQUE,
    Description MEMO,
    CreatedAt DATETIME DEFAULT NOW(),
    UpdatedAt DATETIME DEFAULT NOW()
);

-- 2. جدول الموظفين
CREATE TABLE Employees 
(
    ID AUTOINCREMENT CONSTRAINT PK_Employees PRIMARY KEY,
    Code TEXT(50) NOT NULL CONSTRAINT UQ_EmployeeCode UNIQUE,
    Name TEXT(150) NOT NULL,
    JobTitle TEXT(100),
    DepartmentID LONG CONSTRAINT FK_Employees_Department REFERENCES Departments(ID),
    HireDate DATETIME,
    StartDate DATETIME,
    BirthDate DATETIME,
    NationalID TEXT(20),
    Status TEXT(20) DEFAULT 'active' CHECK (Status IN ('active', 'inactive', 'onleave')),
    Phone TEXT(50),
    Email TEXT(100),
    Address MEMO,
    Notes MEMO,
    CreatedAt DATETIME DEFAULT NOW(),
    UpdatedAt DATETIME DEFAULT NOW()
);

-- 3. جدول الإجازات المرضية
CREATE TABLE SickLeaves 
(
    ID AUTOINCREMENT CONSTRAINT PK_SickLeaves PRIMARY KEY,
    EmployeeID LONG NOT NULL CONSTRAINT FK_SickLeaves_Employee REFERENCES Employees(ID),
    EmpCode TEXT(50),
    EmpName TEXT(150),
    EmpJob TEXT(100),
    DepartmentName TEXT(100),
    DateFrom DATETIME NOT NULL,
    DateTo DATETIME NOT NULL,
    Days LONG DEFAULT 0,
    Diagnosis MEMO,
    DecisionNo TEXT(50),
    Issuer TEXT(150),
    Doctor TEXT(150),
    Status TEXT(20) DEFAULT 'review' CHECK (Status IN ('review', 'approved', 'rejected', 'expired')),
    Notes MEMO,
    AddedBy TEXT(50),
    CreatedAt DATETIME DEFAULT NOW(),
    UpdatedAt DATETIME DEFAULT NOW()
);

CREATE INDEX idx_SickLeaves_EmployeeID ON SickLeaves (EmployeeID);
CREATE INDEX idx_SickLeaves_Status ON SickLeaves (Status);
CREATE INDEX idx_SickLeaves_DateFrom ON SickLeaves (DateFrom);

-- 4. جدول المرفقات (الملفات الطبية)
CREATE TABLE Attachments 
(
    ID AUTOINCREMENT CONSTRAINT PK_Attachments PRIMARY KEY,
    SickLeaveID LONG NOT NULL CONSTRAINT FK_Attachments_SickLeave REFERENCES SickLeaves(ID) ON DELETE CASCADE,
    FileName TEXT(200) NOT NULL,
    FilePath TEXT(500) NOT NULL,
    FileSize LONG,
    FileType TEXT(50),
    CreatedAt DATETIME DEFAULT NOW()
);

-- 5. جدول سلة المهملات
CREATE TABLE Trash 
(
    ID AUTOINCREMENT CONSTRAINT PK_Trash PRIMARY KEY,
    RecordType TEXT(20) NOT NULL,
    OriginalID LONG NOT NULL,
    Data MEMO NOT NULL,
    TrashedBy TEXT(50),
    TrashedAt DATETIME DEFAULT NOW()
);

-- 6. جدول سجل التدقيق
CREATE TABLE AuditLog 
(
    ID AUTOINCREMENT CONSTRAINT PK_AuditLog PRIMARY KEY,
    Action TEXT(50) NOT NULL,
    TableName TEXT(50),
    RecordID LONG,
    Description MEMO,
    Username TEXT(50),
    CreatedAt DATETIME DEFAULT NOW()
);

-- 7. جدول المستخدمين
CREATE TABLE Users 
(
    ID AUTOINCREMENT CONSTRAINT PK_Users PRIMARY KEY,
    Username TEXT(50) NOT NULL CONSTRAINT UQ_UserUsername UNIQUE,
    PasswordHash TEXT(255) NOT NULL,
    PasswordSalt TEXT(255) NOT NULL,
    Role TEXT(20) NOT NULL DEFAULT 'viewer' CHECK (Role IN ('admin', 'hr', 'viewer')),
    IsActive YESNO DEFAULT TRUE,
    CreatedAt DATETIME DEFAULT NOW(),
    LastLogin DATETIME
);

-- 8. جدول إعدادات النظام
CREATE TABLE SystemSettings 
(
    ID AUTOINCREMENT CONSTRAINT PK_Settings PRIMARY KEY,
    SettingKey TEXT(100) NOT NULL CONSTRAINT UQ_SettingKey UNIQUE,
    SettingValue MEMO,
    Description MEMO
);

-- 9. جدول الإشعارات (لمنبهات انتهاء الإجازات)
CREATE TABLE Notifications 
(
    ID AUTOINCREMENT CONSTRAINT PK_Notifications PRIMARY KEY,
    Title TEXT(200) NOT NULL,
    Message MEMO NOT NULL,
    TargetUserID LONG,
    IsRead YESNO DEFAULT FALSE,
    CreatedAt DATETIME DEFAULT NOW()
);

-- 10. إدراج بيانات أولية (الأقسام، مستخدم افتراضي للمشرف)
INSERT INTO Departments (Name, Description) VALUES ('الإدارة', 'الإدارة العامة');
INSERT INTO Departments (Name, Description) VALUES ('الموارد البشرية', 'إدارة شؤون الموظفين');
INSERT INTO Departments (Name, Description) VALUES ('المالية', 'الحسابات والرواتب');
INSERT INTO Departments (Name, Description) VALUES ('التشغيل', 'العمليات التشغيلية');
INSERT INTO Departments (Name, Description) VALUES ('الخدمات', 'الخدمات المساندة');
INSERT INTO Departments (Name, Description) VALUES ('التمريض', 'طاقم التمريض');
INSERT INTO Departments (Name, Description) VALUES ('الأطباء', 'الطاقم الطبي');
INSERT INTO Departments (Name, Description) VALUES ('الصيدلة', 'إدارة الصيدلية');
INSERT INTO Departments (Name, Description) VALUES ('المختبر', 'المختبر الطبي');

-- إعدادات النظام الافتراضية
INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES ('CompanyName', 'المؤسسة الصحية المتكاملة', 'اسم المؤسسة');
INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES ('AutoBackup', 'True', 'تفعيل النسخ الاحتياطي التلقائي');
INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES ('BackupPath', 'C:\Backup', 'مسار حفظ النسخ الاحتياطية');
INSERT INTO SystemSettings (SettingKey, SettingValue, Description) VALUES ('DefaultPasswordLength', '6', 'الحد الأدنى لطول كلمة المرور');

-- سيتم إدراج مستخدم المشرف الأول بعد تشغيل التطبيق (لأن كلمة المرور مشفرة)