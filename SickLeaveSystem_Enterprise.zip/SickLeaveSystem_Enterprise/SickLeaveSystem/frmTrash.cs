using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmTrash : Form
    {
        private DataGridView dgvTrash;
        private Button btnRestore, btnDeletePermanent, btnEmptyTrash, btnRefresh;
        private Label lblTotal;

        public frmTrash()
        {
            InitializeComponent();
            LoadTrash();
            ApplyPermissions();
        }

        private void InitializeComponent()
        {
            this.Text = "سلة المهملات";
            this.Size = new Size(900, 500);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // شريط الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Top;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(13, 24, 40);
            buttonPanel.Padding = new Padding(8);

            btnRestore = new Button();
            btnRestore.Text = "♻️ استعادة";
            btnRestore.FlatStyle = FlatStyle.Flat;
            btnRestore.BackColor = Color.FromArgb(34, 211, 187);
            btnRestore.ForeColor = Color.Black;
            btnRestore.Size = new Size(100, 35);
            btnRestore.Location = new Point(8, 8);
            btnRestore.Click += BtnRestore_Click;

            btnDeletePermanent = new Button();
            btnDeletePermanent.Text = "❌ حذف نهائي";
            btnDeletePermanent.FlatStyle = FlatStyle.Flat;
            btnDeletePermanent.BackColor = Color.FromArgb(240, 79, 100);
            btnDeletePermanent.ForeColor = Color.White;
            btnDeletePermanent.Size = new Size(120, 35);
            btnDeletePermanent.Location = new Point(118, 8);
            btnDeletePermanent.Click += BtnDeletePermanent_Click;

            btnEmptyTrash = new Button();
            btnEmptyTrash.Text = "🗑 إفراغ الكل";
            btnEmptyTrash.FlatStyle = FlatStyle.Flat;
            btnEmptyTrash.BackColor = Color.FromArgb(245, 158, 11);
            btnEmptyTrash.ForeColor = Color.Black;
            btnEmptyTrash.Size = new Size(100, 35);
            btnEmptyTrash.Location = new Point(248, 8);
            btnEmptyTrash.Click += BtnEmptyTrash_Click;

            btnRefresh = new Button();
            btnRefresh.Text = "🔄 تحديث";
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.BackColor = Color.FromArgb(79, 142, 247);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Size = new Size(100, 35);
            btnRefresh.Location = new Point(358, 8);
            btnRefresh.Click += BtnRefresh_Click;

            lblTotal = new Label();
            lblTotal.Text = "العناصر: 0";
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(500, 18);
            lblTotal.AutoSize = true;

            buttonPanel.Controls.Add(btnRestore);
            buttonPanel.Controls.Add(btnDeletePermanent);
            buttonPanel.Controls.Add(btnEmptyTrash);
            buttonPanel.Controls.Add(btnRefresh);
            buttonPanel.Controls.Add(lblTotal);

            // DataGridView
            dgvTrash = new DataGridView();
            dgvTrash.Dock = DockStyle.Fill;
            dgvTrash.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvTrash.ForeColor = Color.White;
            dgvTrash.GridColor = Color.FromArgb(30, 45, 82);
            dgvTrash.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvTrash.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvTrash.MultiSelect = false;
            dgvTrash.ReadOnly = true;
            dgvTrash.RowHeadersVisible = false;
            dgvTrash.AllowUserToAddRows = false;
            dgvTrash.RightToLeft = RightToLeft.Yes;

            this.Controls.Add(dgvTrash);
            this.Controls.Add(buttonPanel);
        }

        private void LoadTrash()
        {
            DataTable dt = BusinessLogic.GetAllTrashItems();
            dgvTrash.DataSource = dt;
            if (dgvTrash.Columns.Count > 0)
            {
                dgvTrash.Columns["ID"].HeaderText = "م";
                dgvTrash.Columns["RecordType"].HeaderText = "النوع";
                dgvTrash.Columns["OriginalID"].HeaderText = "الرقم الأصلي";
                dgvTrash.Columns["Data"].Visible = false;
                dgvTrash.Columns["TrashedBy"].HeaderText = "محذوف بواسطة";
                dgvTrash.Columns["TrashedAt"].HeaderText = "تاريخ الحذف";
                // تنسيق نوع السجل
                dgvTrash.Columns["RecordType"].DefaultCellStyle.FormatProvider = null;
                dgvTrash.CellFormatting += DgvTrash_CellFormatting;
            }
            lblTotal.Text = $"العناصر: {dt.Rows.Count}";
            btnRestore.Enabled = dt.Rows.Count > 0 && SecurityHelper.CanEdit();
            btnDeletePermanent.Enabled = dt.Rows.Count > 0 && SecurityHelper.CanDelete();
            btnEmptyTrash.Enabled = dt.Rows.Count > 0 && SecurityHelper.CanDelete();
        }

        private void DgvTrash_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvTrash.Columns[e.ColumnIndex].Name == "RecordType" && e.Value != null)
            {
                string type = e.Value.ToString();
                if (type == Constants.TrashTypeEmployee)
                    e.Value = "موظف";
                else if (type == Constants.TrashTypeSickLeave)
                    e.Value = "إجازة مرضية";
                e.CellStyle.BackColor = type == Constants.TrashTypeEmployee ? Color.FromArgb(79, 142, 247) : Color.FromArgb(200, 168, 75);
            }
        }

        private void ApplyPermissions()
        {
            if (!SecurityHelper.CanEdit())
            {
                btnRestore.Enabled = false;
                btnDeletePermanent.Enabled = false;
                btnEmptyTrash.Enabled = false;
            }
        }

        private void BtnRestore_Click(object sender, EventArgs e)
        {
            if (dgvTrash.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار عنصر لاستعادته.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int trashId = Convert.ToInt32(dgvTrash.CurrentRow.Cells["ID"].Value);
            string type = dgvTrash.CurrentRow.Cells["RecordType"].Value.ToString();
            int originalId = Convert.ToInt32(dgvTrash.CurrentRow.Cells["OriginalID"].Value);

            // استعادة البيانات من JSON المخزن
            DataTable dtTrash = DatabaseManager.ExecuteQuery("SELECT Data FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId));
            if (dtTrash.Rows.Count == 0) return;
            string jsonData = dtTrash.Rows[0]["Data"].ToString();

            // تحويل JSON إلى DataRow (بسيط باستخدام Newtonsoft.Json أو معالجة يدوية)
            // سنستخدم طريقة بسيطة: استخراج الأعمدة والقيم من النص (للتجنب المكتبات الإضافية)
            // لكن هنا سنفترض وجود مكتبة Newtonsoft.Json (يمكن إضافتها عبر NuGet)
            // بدلاً من ذلك سنستخدم طريقة SQL لإعادة الإدراج من البيانات المخزنة (صعبة)
            // لتجنب التعقيد، سنقوم بتنفيذ استعادة بسيطة: إذا كان النوع موظف، نعيد إدراج بيانات الموظف من جدول Trash عبر استعلام SQL ديناميكي.
            // ولكن بما أننا لا نريد تعقيدًا زائدًا، سنعرض رسالة بأن الاستعادة تحتاج إلى تطوير إضافي، أو يمكننا استخدام JavaScriptSerializer.

            // للتبسيط، سنقوم بإعادة إدراج السجل باستخدام بيانات JSON عبر مكتبة Newtonsoft.Json.
            // يجب إضافة مرجع Newtonsoft.Json.
            try
            {
                if (type == Constants.TrashTypeEmployee)
                {
                    // إعادة إدراج الموظف
                    // سنقوم باستدعاء دالة استعادة مخصصة في BusinessLogic
                    bool restored = RestoreEmployeeFromJson(jsonData);
                    if (restored)
                    {
                        DatabaseManager.ExecuteNonQuery("DELETE FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId));
                        AuditHelper.Log(Constants.AuditActionRestore, Constants.TableEmployees, originalId, "استعادة موظف من سلة المهملات");
                        LoadTrash();
                        MessageBox.Show("تمت استعادة الموظف بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show("فشلت استعادة الموظف.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (type == Constants.TrashTypeSickLeave)
                {
                    bool restored = RestoreSickLeaveFromJson(jsonData);
                    if (restored)
                    {
                        DatabaseManager.ExecuteNonQuery("DELETE FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId));
                        AuditHelper.Log(Constants.AuditActionRestore, Constants.TableSickLeaves, originalId, "استعادة إجازة من سلة المهملات");
                        LoadTrash();
                        MessageBox.Show("تمت استعادة الإجازة بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show("فشلت استعادة الإجازة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في الاستعادة: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool RestoreEmployeeFromJson(string json)
        {
            // استخدام Newtonsoft.Json لتحويل JSON إلى DataRow
            // يجب إضافة مكتبة Newtonsoft.Json عبر NuGet
            // بما أننا لا نستطيع إضافة مكتبات هنا، سنقوم بمعالجة بسيطة: استخراج القيم من JSON باستخدام تعبيرات Regex
            // هذا حل مؤقت. في الإنتاج الحقيقي يفضل استخدام مكتبة Json.NET.
            try
            {
                var jObject = Newtonsoft.Json.Linq.JObject.Parse(json);
                string code = jObject["Code"]?.ToString();
                string name = jObject["Name"]?.ToString();
                string jobTitle = jObject["JobTitle"]?.ToString();
                int deptId = jObject["DepartmentID"] != null ? Convert.ToInt32(jObject["DepartmentID"]) : 0;
                DateTime hireDate = jObject["HireDate"] != null ? Convert.ToDateTime(jObject["HireDate"]) : DateTime.Now;
                DateTime startDate = jObject["StartDate"] != null ? Convert.ToDateTime(jObject["StartDate"]) : DateTime.Now;
                DateTime birthDate = jObject["BirthDate"] != null ? Convert.ToDateTime(jObject["BirthDate"]) : DateTime.Now.AddYears(-30);
                string nationalId = jObject["NationalID"]?.ToString();
                string status = jObject["Status"]?.ToString() ?? Constants.EmployeeStatusActive;
                string phone = jObject["Phone"]?.ToString();
                string email = jObject["Email"]?.ToString();
                string address = jObject["Address"]?.ToString();
                string notes = jObject["Notes"]?.ToString();

                string query = @"INSERT INTO Employees (Code, Name, JobTitle, DepartmentID, HireDate, StartDate, BirthDate, NationalID, Status, Phone, Email, Address, Notes, CreatedAt, UpdatedAt)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
                DatabaseManager.ExecuteNonQuery(query,
                    DatabaseManager.CreateParameter("@Code", code),
                    DatabaseManager.CreateParameter("@Name", name),
                    DatabaseManager.CreateParameter("@JobTitle", jobTitle),
                    DatabaseManager.CreateParameter("@DepartmentID", deptId > 0 ? (object)deptId : DBNull.Value),
                    DatabaseManager.CreateParameter("@HireDate", hireDate),
                    DatabaseManager.CreateParameter("@StartDate", startDate),
                    DatabaseManager.CreateParameter("@BirthDate", birthDate),
                    DatabaseManager.CreateParameter("@NationalID", nationalId),
                    DatabaseManager.CreateParameter("@Status", status),
                    DatabaseManager.CreateParameter("@Phone", phone),
                    DatabaseManager.CreateParameter("@Email", email),
                    DatabaseManager.CreateParameter("@Address", address),
                    DatabaseManager.CreateParameter("@Notes", notes));
                return true;
            }
            catch { return false; }
        }

        private bool RestoreSickLeaveFromJson(string json)
        {
            try
            {
                var jObject = Newtonsoft.Json.Linq.JObject.Parse(json);
                int empId = jObject["EmployeeID"] != null ? Convert.ToInt32(jObject["EmployeeID"]) : 0;
                string empCode = jObject["EmpCode"]?.ToString();
                string empName = jObject["EmpName"]?.ToString();
                string empJob = jObject["EmpJob"]?.ToString();
                string deptName = jObject["DepartmentName"]?.ToString();
                DateTime dateFrom = jObject["DateFrom"] != null ? Convert.ToDateTime(jObject["DateFrom"]) : DateTime.Now;
                DateTime dateTo = jObject["DateTo"] != null ? Convert.ToDateTime(jObject["DateTo"]) : DateTime.Now;
                string diagnosis = jObject["Diagnosis"]?.ToString();
                string decisionNo = jObject["DecisionNo"]?.ToString();
                string issuer = jObject["Issuer"]?.ToString();
                string doctor = jObject["Doctor"]?.ToString();
                string status = jObject["Status"]?.ToString() ?? Constants.SickLeaveStatusReview;
                string notes = jObject["Notes"]?.ToString();
                string addedBy = jObject["AddedBy"]?.ToString();

                string query = @"INSERT INTO SickLeaves (EmployeeID, EmpCode, EmpName, EmpJob, DepartmentName, DateFrom, DateTo, Days, Diagnosis, DecisionNo, Issuer, Doctor, Status, Notes, AddedBy, CreatedAt, UpdatedAt)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
                int days = (dateTo - dateFrom).Days + 1;
                DatabaseManager.ExecuteNonQuery(query,
                    DatabaseManager.CreateParameter("@EmpID", empId),
                    DatabaseManager.CreateParameter("@EmpCode", empCode),
                    DatabaseManager.CreateParameter("@EmpName", empName),
                    DatabaseManager.CreateParameter("@EmpJob", empJob),
                    DatabaseManager.CreateParameter("@DeptName", deptName),
                    DatabaseManager.CreateParameter("@DateFrom", dateFrom),
                    DatabaseManager.CreateParameter("@DateTo", dateTo),
                    DatabaseManager.CreateParameter("@Days", days),
                    DatabaseManager.CreateParameter("@Diag", diagnosis),
                    DatabaseManager.CreateParameter("@DecNo", decisionNo),
                    DatabaseManager.CreateParameter("@Issuer", issuer),
                    DatabaseManager.CreateParameter("@Doctor", doctor),
                    DatabaseManager.CreateParameter("@Status", status),
                    DatabaseManager.CreateParameter("@Notes", notes),
                    DatabaseManager.CreateParameter("@AddedBy", addedBy));
                return true;
            }
            catch { return false; }
        }

        private void BtnDeletePermanent_Click(object sender, EventArgs e)
        {
            if (dgvTrash.CurrentRow == null) return;
            int trashId = Convert.ToInt32(dgvTrash.CurrentRow.Cells["ID"].Value);
            if (MessageBox.Show("هل أنت متأكد من الحذف النهائي؟ لا يمكن التراجع.", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                bool success = BusinessLogic.PermanentDeleteTrash(trashId);
                if (success)
                {
                    AuditHelper.Log("حذف نهائي", Constants.TableTrash, trashId, "حذف عنصر من سلة المهملات نهائياً");
                    LoadTrash();
                }
                else
                    MessageBox.Show("فشل الحذف.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnEmptyTrash_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("هل أنت متأكد من إفراغ سلة المهملات بالكامل؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                bool success = BusinessLogic.EmptyTrash();
                if (success)
                {
                    AuditHelper.Log("إفراغ سلة المهملات", Constants.TableTrash, 0, "تم حذف جميع العناصر نهائياً");
                    LoadTrash();
                }
                else
                    MessageBox.Show("فشل إفراغ السلة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadTrash();
        }
    }
}