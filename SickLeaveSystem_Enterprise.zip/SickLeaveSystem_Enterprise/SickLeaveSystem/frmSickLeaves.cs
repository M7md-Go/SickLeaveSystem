using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmSickLeaves : Form
    {
        private DataTable sickLeavesTable;
        private BindingSource bindingSource;
        private TextBox txtSearch;
        private ComboBox cmbStatus;
        private ComboBox cmbDepartment;
        private DateTimePicker dtpFrom, dtpTo;
        private Button btnSearch;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnRefresh;
        private Button btnExportExcel;
        private Button btnExportCSV;
        private Button btnPrint;
        private DataGridView dgvSickLeaves;
        private Label lblTotal;
        private CheckBox chkDateRange;

        public frmSickLeaves()
        {
            InitializeComponent();
            LoadDepartments();
            LoadStatuses();
            LoadSickLeaves();
            ApplyPermissions();
        }

        private void InitializeComponent()
        {
            this.Text = "إدارة الإجازات المرضية";
            this.Size = new Size(1300, 650);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // لوحة البحث المتقدم
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Height = 95;
            searchPanel.BackColor = Color.FromArgb(13, 24, 40);
            searchPanel.Padding = new Padding(8);

            // صف أول: بحث نصي
            Label lblSearch = new Label();
            lblSearch.Text = "بحث:";
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(10, 12);
            lblSearch.AutoSize = true;
            txtSearch = new TextBox();
            txtSearch.Location = new Point(60, 10);
            txtSearch.Width = 200;
            txtSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtSearch.ForeColor = Color.White;
            txtSearch.TextChanged += TxtSearch_TextChanged;

            Label lblStatus = new Label();
            lblStatus.Text = "الحالة:";
            lblStatus.ForeColor = Color.White;
            lblStatus.Location = new Point(290, 12);
            lblStatus.AutoSize = true;
            cmbStatus = new ComboBox();
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.Location = new Point(340, 10);
            cmbStatus.Width = 130;
            cmbStatus.BackColor = Color.FromArgb(22, 30, 50);
            cmbStatus.ForeColor = Color.White;
            cmbStatus.SelectedIndexChanged += FilterChanged;

            Label lblDept = new Label();
            lblDept.Text = "القسم:";
            lblDept.ForeColor = Color.White;
            lblDept.Location = new Point(500, 12);
            lblDept.AutoSize = true;
            cmbDepartment = new ComboBox();
            cmbDepartment.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDepartment.Location = new Point(550, 10);
            cmbDepartment.Width = 150;
            cmbDepartment.BackColor = Color.FromArgb(22, 30, 50);
            cmbDepartment.ForeColor = Color.White;
            cmbDepartment.SelectedIndexChanged += FilterChanged;

            // صف ثاني: نطاق تاريخي (اختياري)
            chkDateRange = new CheckBox();
            chkDateRange.Text = "تحديد نطاق تاريخي";
            chkDateRange.ForeColor = Color.White;
            chkDateRange.Location = new Point(10, 45);
            chkDateRange.AutoSize = true;
            chkDateRange.CheckedChanged += ChkDateRange_CheckedChanged;

            Label lblFrom = new Label();
            lblFrom.Text = "من تاريخ:";
            lblFrom.ForeColor = Color.White;
            lblFrom.Location = new Point(130, 45);
            lblFrom.AutoSize = true;
            dtpFrom = new DateTimePicker();
            dtpFrom.Format = DateTimePickerFormat.Short;
            dtpFrom.Location = new Point(200, 43);
            dtpFrom.Width = 110;
            dtpFrom.Enabled = false;
            dtpFrom.ValueChanged += FilterChanged;

            Label lblTo = new Label();
            lblTo.Text = "إلى تاريخ:";
            lblTo.ForeColor = Color.White;
            lblTo.Location = new Point(330, 45);
            lblTo.AutoSize = true;
            dtpTo = new DateTimePicker();
            dtpTo.Format = DateTimePickerFormat.Short;
            dtpTo.Location = new Point(400, 43);
            dtpTo.Width = 110;
            dtpTo.Enabled = false;
            dtpTo.ValueChanged += FilterChanged;

            btnSearch = new Button();
            btnSearch.Text = "🔍 بحث";
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.BackColor = Color.FromArgb(200, 168, 75);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Location = new Point(530, 43);
            btnSearch.Size = new Size(85, 28);
            btnSearch.Click += BtnSearch_Click;

            btnRefresh = new Button();
            btnRefresh.Text = "🔄 تحديث";
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.BackColor = Color.FromArgb(79, 142, 247);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(625, 43);
            btnRefresh.Size = new Size(85, 28);
            btnRefresh.Click += BtnRefresh_Click;

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(lblStatus);
            searchPanel.Controls.Add(cmbStatus);
            searchPanel.Controls.Add(lblDept);
            searchPanel.Controls.Add(cmbDepartment);
            searchPanel.Controls.Add(chkDateRange);
            searchPanel.Controls.Add(lblFrom);
            searchPanel.Controls.Add(dtpFrom);
            searchPanel.Controls.Add(lblTo);
            searchPanel.Controls.Add(dtpTo);
            searchPanel.Controls.Add(btnSearch);
            searchPanel.Controls.Add(btnRefresh);

            // شريط الأزرار السفلية
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 55;
            buttonPanel.BackColor = Color.FromArgb(13, 24, 40);
            buttonPanel.Padding = new Padding(8);

            btnAdd = new Button();
            btnAdd.Text = "➕ إضافة إجازة";
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.BackColor = Color.FromArgb(34, 211, 187);
            btnAdd.ForeColor = Color.Black;
            btnAdd.Size = new Size(120, 35);
            btnAdd.Location = new Point(8, 8);
            btnAdd.Click += BtnAdd_Click;

            btnEdit = new Button();
            btnEdit.Text = "✏️ تعديل";
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.BackColor = Color.FromArgb(79, 142, 247);
            btnEdit.ForeColor = Color.White;
            btnEdit.Size = new Size(100, 35);
            btnEdit.Location = new Point(138, 8);
            btnEdit.Click += BtnEdit_Click;

            btnDelete = new Button();
            btnDelete.Text = "🗑 حذف";
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.BackColor = Color.FromArgb(240, 79, 100);
            btnDelete.ForeColor = Color.White;
            btnDelete.Size = new Size(100, 35);
            btnDelete.Location = new Point(248, 8);
            btnDelete.Click += BtnDelete_Click;

            btnExportExcel = new Button();
            btnExportExcel.Text = "📊 Excel";
            btnExportExcel.FlatStyle = FlatStyle.Flat;
            btnExportExcel.BackColor = Color.FromArgb(16, 201, 127);
            btnExportExcel.ForeColor = Color.Black;
            btnExportExcel.Size = new Size(90, 35);
            btnExportExcel.Location = new Point(358, 8);
            btnExportExcel.Click += BtnExportExcel_Click;

            btnExportCSV = new Button();
            btnExportCSV.Text = "📄 CSV";
            btnExportCSV.FlatStyle = FlatStyle.Flat;
            btnExportCSV.BackColor = Color.FromArgb(167, 139, 250);
            btnExportCSV.ForeColor = Color.White;
            btnExportCSV.Size = new Size(80, 35);
            btnExportCSV.Location = new Point(458, 8);
            btnExportCSV.Click += BtnExportCSV_Click;

            btnPrint = new Button();
            btnPrint.Text = "🖨️ طباعة";
            btnPrint.FlatStyle = FlatStyle.Flat;
            btnPrint.BackColor = Color.FromArgb(245, 158, 11);
            btnPrint.ForeColor = Color.Black;
            btnPrint.Size = new Size(80, 35);
            btnPrint.Location = new Point(548, 8);
            btnPrint.Click += BtnPrint_Click;

            lblTotal = new Label();
            lblTotal.Text = "إجمالي الإجازات: 0";
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(700, 18);
            lblTotal.AutoSize = true;

            buttonPanel.Controls.Add(btnAdd);
            buttonPanel.Controls.Add(btnEdit);
            buttonPanel.Controls.Add(btnDelete);
            buttonPanel.Controls.Add(btnExportExcel);
            buttonPanel.Controls.Add(btnExportCSV);
            buttonPanel.Controls.Add(btnPrint);
            buttonPanel.Controls.Add(lblTotal);

            // DataGridView
            dgvSickLeaves = new DataGridView();
            dgvSickLeaves.Dock = DockStyle.Fill;
            dgvSickLeaves.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvSickLeaves.ForeColor = Color.White;
            dgvSickLeaves.GridColor = Color.FromArgb(30, 45, 82);
            dgvSickLeaves.BorderStyle = BorderStyle.None;
            dgvSickLeaves.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvSickLeaves.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSickLeaves.MultiSelect = false;
            dgvSickLeaves.ReadOnly = true;
            dgvSickLeaves.RowHeadersVisible = false;
            dgvSickLeaves.AllowUserToAddRows = false;
            dgvSickLeaves.RightToLeft = RightToLeft.Yes;
            dgvSickLeaves.CellDoubleClick += DgvSickLeaves_CellDoubleClick;
            dgvSickLeaves.CellFormatting += DgvSickLeaves_CellFormatting;

            this.Controls.Add(dgvSickLeaves);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(searchPanel);
        }

        private void LoadDepartments()
        {
            DataTable dt = BusinessLogic.GetAllDepartments();
            dt.Rows.InsertAt(dt.NewRow(), 0);
            dt.Rows[0]["ID"] = 0;
            dt.Rows[0]["Name"] = "الكل";
            cmbDepartment.DataSource = dt;
            cmbDepartment.DisplayMember = "Name";
            cmbDepartment.ValueMember = "ID";
            cmbDepartment.SelectedValue = 0;
        }

        private void LoadStatuses()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Value");
            dt.Columns.Add("Text");
            dt.Rows.Add("", "الكل");
            dt.Rows.Add(Constants.SickLeaveStatusReview, "تحت المراجعة");
            dt.Rows.Add(Constants.SickLeaveStatusApproved, "معتمدة");
            dt.Rows.Add(Constants.SickLeaveStatusRejected, "مرفوضة");
            dt.Rows.Add(Constants.SickLeaveStatusExpired, "منتهية");
            cmbStatus.DataSource = dt;
            cmbStatus.DisplayMember = "Text";
            cmbStatus.ValueMember = "Value";
            cmbStatus.SelectedIndex = 0;
        }

        private void LoadSickLeaves()
        {
            string keyword = txtSearch.Text.Trim();
            string status = cmbStatus.SelectedValue?.ToString() == "" ? null : cmbStatus.SelectedValue?.ToString();
            int? deptId = null;
            if (cmbDepartment.SelectedValue != null && Convert.ToInt32(cmbDepartment.SelectedValue) > 0)
                deptId = Convert.ToInt32(cmbDepartment.SelectedValue);

            string dateFilter = "";
            if (chkDateRange.Checked)
            {
                dateFilter = $" AND DateFrom >= #{dtpFrom.Value:yyyy-MM-dd}# AND DateTo <= #{dtpTo.Value:yyyy-MM-dd}#";
            }

            string query = @"
                SELECT sl.*, 
                       (SELECT COUNT(*) FROM Attachments WHERE SickLeaveID=sl.ID) AS AttachmentsCount
                FROM SickLeaves sl 
                WHERE 1=1 ";

            if (!string.IsNullOrEmpty(keyword))
                query += " AND (sl.EmpName LIKE '%" + keyword.Replace("'", "''") + "%' OR sl.EmpCode LIKE '%" + keyword.Replace("'", "''") + "%' OR sl.Diagnosis LIKE '%" + keyword.Replace("'", "''") + "%' OR sl.DecisionNo LIKE '%" + keyword.Replace("'", "''") + "%')";
            if (!string.IsNullOrEmpty(status))
                query += " AND sl.Status = '" + status + "'";
            if (deptId.HasValue)
                query += " AND sl.DepartmentID = " + deptId.Value;
            query += dateFilter;
            query += " ORDER BY sl.ID DESC";

            sickLeavesTable = DatabaseManager.ExecuteQuery(query);
            bindingSource = new BindingSource();
            bindingSource.DataSource = sickLeavesTable;
            dgvSickLeaves.DataSource = bindingSource;

            // تخصيص الأعمدة
            if (dgvSickLeaves.Columns.Count > 0)
            {
                dgvSickLeaves.Columns["ID"].HeaderText = "م";
                dgvSickLeaves.Columns["EmpCode"].HeaderText = "كود الموظف";
                dgvSickLeaves.Columns["EmpName"].HeaderText = "اسم الموظف";
                dgvSickLeaves.Columns["DepartmentName"].HeaderText = "القسم";
                dgvSickLeaves.Columns["DateFrom"].HeaderText = "من تاريخ";
                dgvSickLeaves.Columns["DateTo"].HeaderText = "إلى تاريخ";
                dgvSickLeaves.Columns["Days"].HeaderText = "الأيام";
                dgvSickLeaves.Columns["DecisionNo"].HeaderText = "القرار 259";
                dgvSickLeaves.Columns["Status"].HeaderText = "الحالة";
                dgvSickLeaves.Columns["AttachmentsCount"].HeaderText = "المرفقات";

                // إخفاء الأعمدة غير المرغوب فيها
                string[] hidden = { "EmployeeID", "EmpJob", "Diagnosis", "Issuer", "Doctor", "Notes", "AddedBy", "CreatedAt", "UpdatedAt" };
                foreach (string col in hidden)
                    if (dgvSickLeaves.Columns.Contains(col))
                        dgvSickLeaves.Columns[col].Visible = false;
            }
            lblTotal.Text = $"إجمالي الإجازات: {sickLeavesTable.Rows.Count}";
        }

        private void ApplyPermissions()
        {
            bool canEdit = SecurityHelper.CanEdit();
            btnAdd.Enabled = canEdit;
            btnEdit.Enabled = canEdit;
            btnDelete.Enabled = SecurityHelper.CanDelete();
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadSickLeaves();
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            LoadSickLeaves();
        }

        private void ChkDateRange_CheckedChanged(object sender, EventArgs e)
        {
            dtpFrom.Enabled = chkDateRange.Checked;
            dtpTo.Enabled = chkDateRange.Checked;
            LoadSickLeaves();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadSickLeaves();
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbStatus.SelectedIndex = 0;
            cmbDepartment.SelectedValue = 0;
            chkDateRange.Checked = false;
            dtpFrom.Value = DateTime.Now.AddDays(-30);
            dtpTo.Value = DateTime.Now;
            LoadSickLeaves();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بإضافة إجازات.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            frmSickLeaveDetail detail = new frmSickLeaveDetail();
            if (detail.ShowDialog() == DialogResult.OK)
                LoadSickLeaves();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بتعديل الإجازات.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dgvSickLeaves.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار إجازة أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvSickLeaves.CurrentRow.Cells["ID"].Value);
            frmSickLeaveDetail detail = new frmSickLeaveDetail(id);
            if (detail.ShowDialog() == DialogResult.OK)
                LoadSickLeaves();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanDelete())
            {
                MessageBox.Show("غير مصرح لك بحذف الإجازات.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dgvSickLeaves.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار إجازة أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvSickLeaves.CurrentRow.Cells["ID"].Value);
            string empName = dgvSickLeaves.CurrentRow.Cells["EmpName"].Value.ToString();
            if (MessageBox.Show($"هل أنت متأكد من حذف إجازة '{empName}'؟ سيتم نقلها إلى سلة المهملات.", "تأكيد الحذف",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                bool success = BusinessLogic.DeleteSickLeave(id, GlobalState.CurrentUser.Username);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionDelete, Constants.TableSickLeaves, id, $"حذف إجازة للموظف: {empName}");
                    LoadSickLeaves();
                    MessageBox.Show("تم حذف الإجازة ونقلها إلى سلة المهملات.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("فشل حذف الإجازة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            ExportHelper.ExportDataGridViewToCSV(dgvSickLeaves, "SickLeaves_Report.csv");
            // يمكن تحسينه لتصدير Excel حقيقي
        }

        private void BtnExportCSV_Click(object sender, EventArgs e)
        {
            ExportHelper.ExportDataGridViewToCSV(dgvSickLeaves, "SickLeaves_Report.csv");
        }

        private void BtnPrint_Click(object sender, EventArgs e)
        {
            ReportHelper.PrintPreview(sickLeavesTable, "تقرير الإجازات المرضية");
        }

        private void DgvSickLeaves_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int id = Convert.ToInt32(dgvSickLeaves.Rows[e.RowIndex].Cells["ID"].Value);
                frmSickLeaveDetail detail = new frmSickLeaveDetail(id, true);
                detail.ShowDialog();
            }
        }

        private void DgvSickLeaves_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvSickLeaves.Columns[e.ColumnIndex].Name == "Status" && e.Value != null)
            {
                string status = e.Value.ToString();
                switch (status)
                {
                    case "approved":
                        e.CellStyle.BackColor = Color.FromArgb(16, 201, 127);
                        e.CellStyle.ForeColor = Color.Black;
                        e.Value = "✅ معتمدة";
                        break;
                    case "rejected":
                        e.CellStyle.BackColor = Color.FromArgb(240, 79, 100);
                        e.CellStyle.ForeColor = Color.White;
                        e.Value = "❌ مرفوضة";
                        break;
                    case "review":
                        e.CellStyle.BackColor = Color.FromArgb(79, 142, 247);
                        e.CellStyle.ForeColor = Color.White;
                        e.Value = "⏳ تحت المراجعة";
                        break;
                    case "expired":
                        e.CellStyle.BackColor = Color.FromArgb(128, 128, 128);
                        e.CellStyle.ForeColor = Color.White;
                        e.Value = "⏰ منتهية";
                        break;
                }
            }
            if (dgvSickLeaves.Columns[e.ColumnIndex].Name == "AttachmentsCount" && e.Value != null)
            {
                int count = Convert.ToInt32(e.Value);
                e.Value = count > 0 ? $"📎 {count}" : "—";
            }
        }
    }
}