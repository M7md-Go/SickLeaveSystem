using System;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmSettings : Form
    {
        private TextBox txtCompanyName, txtBackupPath;
        private CheckBox chkAutoBackup;
        private NumericUpDown numBackupInterval;
        private Button btnSave, btnCancel;

        public frmSettings()
        {
            InitializeComponent();
            LoadSettings();
        }

        private void InitializeComponent()
        {
            this.Text = "إعدادات النظام";
            this.Size = new Size(550, 350);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(13, 24, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            TableLayoutPanel tlp = new TableLayoutPanel();
            tlp.Dock = DockStyle.Fill;
            tlp.ColumnCount = 2;
            tlp.RowCount = 4;
            tlp.Padding = new Padding(15);
            tlp.BackColor = Color.FromArgb(13, 24, 40);

            // اسم المؤسسة
            Label lblCompany = new Label();
            lblCompany.Text = "اسم المؤسسة:";
            lblCompany.ForeColor = Color.White;
            txtCompanyName = new TextBox();
            txtCompanyName.BackColor = Color.FromArgb(22, 30, 50);
            txtCompanyName.ForeColor = Color.White;
            tlp.Controls.Add(lblCompany, 0, 0);
            tlp.Controls.Add(txtCompanyName, 1, 0);

            // النسخ الاحتياطي التلقائي
            Label lblAuto = new Label();
            lblAuto.Text = "نسخ احتياطي تلقائي:";
            lblAuto.ForeColor = Color.White;
            chkAutoBackup = new CheckBox();
            chkAutoBackup.Text = "مفعل";
            chkAutoBackup.ForeColor = Color.White;
            tlp.Controls.Add(lblAuto, 0, 1);
            tlp.Controls.Add(chkAutoBackup, 1, 1);

            // الفاصل الزمني
            Label lblInterval = new Label();
            lblInterval.Text = "الفاصل بين النسخ (ساعات):";
            lblInterval.ForeColor = Color.White;
            numBackupInterval = new NumericUpDown();
            numBackupInterval.Minimum = 1;
            numBackupInterval.Maximum = 168;
            numBackupInterval.Value = 24;
            numBackupInterval.BackColor = Color.FromArgb(22, 30, 50);
            numBackupInterval.ForeColor = Color.White;
            tlp.Controls.Add(lblInterval, 0, 2);
            tlp.Controls.Add(numBackupInterval, 1, 2);

            // مسار النسخ الاحتياطي
            Label lblPath = new Label();
            lblPath.Text = "مسار النسخ الاحتياطي:";
            lblPath.ForeColor = Color.White;
            Panel pathPanel = new Panel();
            txtBackupPath = new TextBox();
            txtBackupPath.BackColor = Color.FromArgb(22, 30, 50);
            txtBackupPath.ForeColor = Color.White;
            txtBackupPath.Dock = DockStyle.Fill;
            Button btnBrowse = new Button();
            btnBrowse.Text = "📁";
            btnBrowse.FlatStyle = FlatStyle.Flat;
            btnBrowse.BackColor = Color.FromArgb(200, 168, 75);
            btnBrowse.Dock = DockStyle.Right;
            btnBrowse.Width = 40;
            btnBrowse.Click += BtnBrowse_Click;
            pathPanel.Controls.Add(txtBackupPath);
            pathPanel.Controls.Add(btnBrowse);
            tlp.Controls.Add(lblPath, 0, 3);
            tlp.Controls.Add(pathPanel, 1, 3);

            this.Controls.Add(tlp);

            // لوحة الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(8, 15, 30);

            btnSave = new Button();
            btnSave.Text = "💾 حفظ الإعدادات";
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.BackColor = Color.FromArgb(16, 201, 127);
            btnSave.ForeColor = Color.Black;
            btnSave.Size = new Size(130, 35);
            btnSave.Location = new Point(100, 8);
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button();
            btnCancel.Text = "إلغاء";
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.BackColor = Color.FromArgb(240, 79, 100);
            btnCancel.ForeColor = Color.White;
            btnCancel.Size = new Size(100, 35);
            btnCancel.Location = new Point(240, 8);
            btnCancel.Click += (s, e) => this.Close();

            buttonPanel.Controls.Add(btnSave);
            buttonPanel.Controls.Add(btnCancel);
            this.Controls.Add(buttonPanel);
        }

        private void LoadSettings()
        {
            txtCompanyName.Text = GlobalState.GetSetting(Constants.SettingCompanyName, "المؤسسة الصحية المتكاملة");
            chkAutoBackup.Checked = GlobalState.AutoBackupEnabled;
            string interval = GlobalState.GetSetting("BackupIntervalHours", "24");
            numBackupInterval.Value = int.TryParse(interval, out int val) ? val : 24;
            txtBackupPath.Text = GlobalState.BackupPath;
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "اختر مجلد حفظ النسخ الاحتياطية";
                fbd.SelectedPath = txtBackupPath.Text;
                if (fbd.ShowDialog() == DialogResult.OK)
                    txtBackupPath.Text = fbd.SelectedPath;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            GlobalState.SetSetting(Constants.SettingCompanyName, txtCompanyName.Text);
            GlobalState.SetSetting(Constants.SettingAutoBackup, chkAutoBackup.Checked ? "True" : "False");
            GlobalState.SetSetting("BackupIntervalHours", numBackupInterval.Value.ToString());
            GlobalState.SetSetting(Constants.SettingBackupPath, txtBackupPath.Text);
            MessageBox.Show("تم حفظ الإعدادات بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}