using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmUsers : Form
    {
        private DataGridView dgvUsers;
        private Button btnAdd, btnEdit, btnDelete, btnRefresh;
        private Label lblTotal;
        private TextBox txtSearch;
        private Button btnSearch;

        public frmUsers()
        {
            InitializeComponent();
            LoadUsers();
            ApplyPermissions();
        }

        private void InitializeComponent()
        {
            this.Text = "إدارة المستخدمين";
            this.Size = new Size(800, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // لوحة البحث
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Height = 50;
            searchPanel.BackColor = Color.FromArgb(13, 24, 40);
            searchPanel.Padding = new Padding(8);

            Label lblSearch = new Label();
            lblSearch.Text = "بحث:";
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(10, 12);
            lblSearch.AutoSize = true;

            txtSearch = new TextBox();
            txtSearch.Location = new Point(60, 10);
            txtSearch.Width = 200;
            txtSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtSearch.ForeColor = Color.White;
            txtSearch.TextChanged += TxtSearch_TextChanged;

            btnSearch = new Button();
            btnSearch.Text = "🔍 بحث";
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.BackColor = Color.FromArgb(200, 168, 75);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Size = new Size(80, 28);
            btnSearch.Location = new Point(280, 8);
            btnSearch.Click += BtnSearch_Click;

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(btnSearch);

            // شريط الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(13, 24, 40);
            buttonPanel.Padding = new Padding(8);

            btnAdd = new Button();
            btnAdd.Text = "➕ إضافة مستخدم";
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.BackColor = Color.FromArgb(16, 201, 127);
            btnAdd.ForeColor = Color.Black;
            btnAdd.Size = new Size(120, 35);
            btnAdd.Location = new Point(8, 8);
            btnAdd.Click += BtnAdd_Click;

            btnEdit = new Button();
            btnEdit.Text = "✏️ تعديل";
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.BackColor = Color.FromArgb(79, 142, 247);
            btnEdit.ForeColor = Color.White;
            btnEdit.Size = new Size(100, 35);
            btnEdit.Location = new Point(138, 8);
            btnEdit.Click += BtnEdit_Click;

            btnDelete = new Button();
            btnDelete.Text = "🗑 حذف";
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.BackColor = Color.FromArgb(240, 79, 100);
            btnDelete.ForeColor = Color.White;
            btnDelete.Size = new Size(100, 35);
            btnDelete.Location = new Point(248, 8);
            btnDelete.Click += BtnDelete_Click;

            btnRefresh = new Button();
            btnRefresh.Text = "🔄 تحديث";
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.BackColor = Color.FromArgb(245, 158, 11);
            btnRefresh.ForeColor = Color.Black;
            btnRefresh.Size = new Size(100, 35);
            btnRefresh.Location = new Point(358, 8);
            btnRefresh.Click += BtnRefresh_Click;

            lblTotal = new Label();
            lblTotal.Text = "إجمالي المستخدمين: 0";
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(500, 18);
            lblTotal.AutoSize = true;

            buttonPanel.Controls.Add(btnAdd);
            buttonPanel.Controls.Add(btnEdit);
            buttonPanel.Controls.Add(btnDelete);
            buttonPanel.Controls.Add(btnRefresh);
            buttonPanel.Controls.Add(lblTotal);

            // DataGridView
            dgvUsers = new DataGridView();
            dgvUsers.Dock = DockStyle.Fill;
            dgvUsers.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvUsers.ForeColor = Color.White;
            dgvUsers.GridColor = Color.FromArgb(30, 45, 82);
            dgvUsers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUsers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUsers.MultiSelect = false;
            dgvUsers.ReadOnly = true;
            dgvUsers.RowHeadersVisible = false;
            dgvUsers.AllowUserToAddRows = false;
            dgvUsers.RightToLeft = RightToLeft.Yes;

            this.Controls.Add(dgvUsers);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(searchPanel);
        }

        private void LoadUsers()
        {
            string filter = txtSearch.Text.Trim();
            DataTable dt = BusinessLogic.GetAllUsers();
            if (!string.IsNullOrEmpty(filter))
            {
                DataTable filtered = dt.Clone();
                foreach (DataRow row in dt.Rows)
                {
                    if (row["Username"].ToString().ToLower().Contains(filter.ToLower()))
                        filtered.ImportRow(row);
                }
                dt = filtered;
            }
            dgvUsers.DataSource = dt;
            if (dgvUsers.Columns.Count > 0)
            {
                dgvUsers.Columns["ID"].HeaderText = "م";
                dgvUsers.Columns["Username"].HeaderText = "اسم المستخدم";
                dgvUsers.Columns["Role"].HeaderText = "الصلاحية";
                dgvUsers.Columns["IsActive"].HeaderText = "نشط";
                dgvUsers.Columns["CreatedAt"].HeaderText = "تاريخ الإنشاء";
                dgvUsers.Columns["LastLogin"].HeaderText = "آخر دخول";
                if (dgvUsers.Columns.Contains("PasswordHash")) dgvUsers.Columns["PasswordHash"].Visible = false;
                if (dgvUsers.Columns.Contains("PasswordSalt")) dgvUsers.Columns["PasswordSalt"].Visible = false;
                dgvUsers.Columns["IsActive"].DefaultCellStyle.NullValue = "لا";
            }
            lblTotal.Text = $"إجمالي المستخدمين: {dt.Rows.Count}";
        }

        private void ApplyPermissions()
        {
            bool isAdmin = SecurityHelper.HasAccess(Constants.RoleAdmin);
            btnAdd.Enabled = isAdmin;
            btnEdit.Enabled = isAdmin;
            btnDelete.Enabled = isAdmin;
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin)) return;
            frmUserDetail detail = new frmUserDetail();
            if (detail.ShowDialog() == DialogResult.OK)
                LoadUsers();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin)) return;
            if (dgvUsers.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار مستخدم أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvUsers.CurrentRow.Cells["ID"].Value);
            string username = dgvUsers.CurrentRow.Cells["Username"].Value.ToString();
            string role = dgvUsers.CurrentRow.Cells["Role"].Value.ToString();
            bool isActive = Convert.ToBoolean(dgvUsers.CurrentRow.Cells["IsActive"].Value);
            frmUserDetail detail = new frmUserDetail(id, username, role, isActive);
            if (detail.ShowDialog() == DialogResult.OK)
                LoadUsers();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin)) return;
            if (dgvUsers.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار مستخدم أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvUsers.CurrentRow.Cells["ID"].Value);
            string username = dgvUsers.CurrentRow.Cells["Username"].Value.ToString();
            if (id == GlobalState.CurrentUser.ID)
            {
                MessageBox.Show("لا يمكنك حذف حساب المستخدم الحالي نفسه.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (MessageBox.Show($"هل أنت متأكد من حذف المستخدم '{username}'؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                bool success = BusinessLogic.DeleteUser(id);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionDelete, Constants.TableUsers, id, $"حذف مستخدم: {username}");
                    LoadUsers();
                }
                else
                    MessageBox.Show("فشل حذف المستخدم.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadUsers();
        }
    }
}