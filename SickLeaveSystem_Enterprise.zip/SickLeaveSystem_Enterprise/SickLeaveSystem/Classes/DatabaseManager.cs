using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// مدير الاتصال بقاعدة البيانات وتنفيذ الاستعلامات
    /// </summary>
    public class DatabaseManager
    {
        private static string connectionString = null;

        /// <summary>
        /// الحصول على سلسلة الاتصال من ملف التكوين
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(connectionString))
                {
                    connectionString = ConfigurationManager.ConnectionStrings["SickLeaveDB"].ConnectionString;
                    // التأكد من صحة المسار
                    string dataDir = AppDomain.CurrentDomain.BaseDirectory;
                    connectionString = connectionString.Replace("|DataDirectory|", dataDir);
                }
                return connectionString;
            }
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع DataTable
        /// </summary>
        public static DataTable ExecuteQuery(string query, params OleDbParameter[] parameters)
        {
            DataTable dt = new DataTable();
            try
            {
                using (OleDbConnection conn = new OleDbConnection(ConnectionString))
                {
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        if (parameters != null)
                            cmd.Parameters.AddRange(parameters);
                        using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                        {
                            da.Fill(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // تسجيل الخطأ
                MessageBox.Show("خطأ في قاعدة البيانات: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
            return dt;
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع قيمة مفردة
        /// </summary>
        public static object ExecuteScalar(string query, params OleDbParameter[] parameters)
        {
            object result = null;
            try
            {
                using (OleDbConnection conn = new OleDbConnection(ConnectionString))
                {
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        if (parameters != null)
                            cmd.Parameters.AddRange(parameters);
                        conn.Open();
                        result = cmd.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في قاعدة البيانات: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
            return result;
        }

        /// <summary>
        /// تنفيذ استعلام عدم إرجاع بيانات (INSERT, UPDATE, DELETE)
        /// </summary>
        public static int ExecuteNonQuery(string query, params OleDbParameter[] parameters)
        {
            int rowsAffected = 0;
            try
            {
                using (OleDbConnection conn = new OleDbConnection(ConnectionString))
                {
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        if (parameters != null)
                            cmd.Parameters.AddRange(parameters);
                        conn.Open();
                        rowsAffected = cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تنفيذ العملية: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw;
            }
            return rowsAffected;
        }

        /// <summary>
        /// تنفيذ استعلام وإرجاع معرف السجل المضاف (لـ AutoNumber)
        /// </summary>
        public static int ExecuteInsertGetIdentity(string query, params OleDbParameter[] parameters)
        {
            int identity = -1;
            using (OleDbConnection conn = new OleDbConnection(ConnectionString))
            {
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    if (parameters != null)
                        cmd.Parameters.AddRange(parameters);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    // استعلام لاسترجاع آخر قيمة AUTOINCREMENT
                    cmd.CommandText = "SELECT @@IDENTITY";
                    identity = Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
            return identity;
        }

        /// <summary>
        /// إنشاء معامل OleDbParameter
        /// </summary>
        public static OleDbParameter CreateParameter(string name, object value)
        {
            return new OleDbParameter(name, value ?? DBNull.Value);
        }
    }
}