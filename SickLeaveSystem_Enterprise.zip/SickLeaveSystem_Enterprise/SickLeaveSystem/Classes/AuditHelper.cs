using System;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// مساعد تسجيل سجل التدقيق (Audit Log)
    /// </summary>
    public static class AuditHelper
    {
        /// <summary>
        /// إضافة سجل إلى AuditLog
        /// </summary>
        /// <param name="action">نوع العملية (إضافة، تعديل، حذف، الخ)</param>
        /// <param name="tableName">اسم الجدول المتأثر</param>
        /// <param name="recordId">رقم السجل المتأثر</param>
        /// <param name="description">وصف تفصيلي</param>
        public static void Log(string action, string tableName, int recordId, string description)
        {
            string username = GlobalState.CurrentUser != null ? GlobalState.CurrentUser.Username : "نظام";
            string query = @"INSERT INTO AuditLog (Action, TableName, RecordID, Description, Username, CreatedAt) 
                             VALUES (?, ?, ?, ?, ?, NOW())";
            DatabaseManager.ExecuteNonQuery(query,
                DatabaseManager.CreateParameter("@action", action),
                DatabaseManager.CreateParameter("@table", tableName),
                DatabaseManager.CreateParameter("@rid", recordId),
                DatabaseManager.CreateParameter("@desc", description),
                DatabaseManager.CreateParameter("@user", username));
        }

        /// <summary>
        /// تسجيل دخول المستخدم
        /// </summary>
        public static void LogLogin(string username, bool success)
        {
            string action = success ? Constants.AuditActionLogin : "محاولة دخول فاشلة";
            string desc = success ? $"تسجيل دخول ناجح للمستخدم {username}" : $"محاولة دخول فاشلة باسم {username}";
            DatabaseManager.ExecuteNonQuery(
                "INSERT INTO AuditLog (Action, TableName, RecordID, Description, Username, CreatedAt) VALUES (?, ?, ?, ?, ?, NOW())",
                DatabaseManager.CreateParameter("@action", action),
                DatabaseManager.CreateParameter("@table", ""),
                DatabaseManager.CreateParameter("@rid", 0),
                DatabaseManager.CreateParameter("@desc", desc),
                DatabaseManager.CreateParameter("@user", username));
        }

        /// <summary>
        /// تسجيل خروج المستخدم
        /// </summary>
        public static void LogLogout(string username)
        {
            DatabaseManager.ExecuteNonQuery(
                "INSERT INTO AuditLog (Action, TableName, RecordID, Description, Username, CreatedAt) VALUES (?, ?, ?, ?, ?, NOW())",
                DatabaseManager.CreateParameter("@action", Constants.AuditActionLogout),
                DatabaseManager.CreateParameter("@table", ""),
                DatabaseManager.CreateParameter("@rid", 0),
                DatabaseManager.CreateParameter("@desc", $"تسجيل خروج المستخدم {username}"),
                DatabaseManager.CreateParameter("@user", username));
        }
    }
}