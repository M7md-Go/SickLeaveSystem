using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// طبقة منطق الأعمال - تحتوي على دوال معالجة البيانات والتحقق من الصلاحيات
    /// </summary>
    public static class BusinessLogic
    {
        #region العمليات على الموظفين

        /// <summary>
        /// جلب جميع الموظفين مع أسماء الأقسام
        /// </summary>
        public static DataTable GetAllEmployees()
        {
            string query = @"SELECT e.*, d.Name AS DepartmentName 
                             FROM Employees e 
                             LEFT JOIN Departments d ON e.DepartmentID = d.ID
                             ORDER BY e.Name";
            return DatabaseManager.ExecuteQuery(query);
        }

        /// <summary>
        /// البحث عن الموظفين حسب كود أو اسم أو قسم
        /// </summary>
        public static DataTable SearchEmployees(string keyword, int? departmentId, string status)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(@"SELECT e.*, d.Name AS DepartmentName 
                        FROM Employees e 
                        LEFT JOIN Departments d ON e.DepartmentID = d.ID WHERE 1=1");
            List<object> paramList = new List<object>();

            if (!string.IsNullOrEmpty(keyword))
            {
                sb.Append(" AND (e.Code LIKE ? OR e.Name LIKE ?)");
                paramList.Add($"%{keyword}%");
                paramList.Add($"%{keyword}%");
            }
            if (departmentId.HasValue && departmentId.Value > 0)
            {
                sb.Append(" AND e.DepartmentID = ?");
                paramList.Add(departmentId.Value);
            }
            if (!string.IsNullOrEmpty(status) && status != "الكل")
            {
                string statusVal = status == "نشط" ? Constants.EmployeeStatusActive :
                                   status == "غير نشط" ? Constants.EmployeeStatusInactive : Constants.EmployeeStatusOnLeave;
                sb.Append(" AND e.Status = ?");
                paramList.Add(statusVal);
            }
            sb.Append(" ORDER BY e.Name");

            OleDbParameter[] parameters = new OleDbParameter[paramList.Count];
            for (int i = 0; i < paramList.Count; i++)
                parameters[i] = DatabaseManager.CreateParameter($"@p{i}", paramList[i]);

            return DatabaseManager.ExecuteQuery(sb.ToString(), parameters);
        }

        /// <summary>
        /// إضافة موظف جديد
        /// </summary>
        public static int AddEmployee(EmployeeModel emp)
        {
            string query = @"INSERT INTO Employees (Code, Name, JobTitle, DepartmentID, HireDate, StartDate, 
                            BirthDate, NationalID, Status, Phone, Email, Address, Notes, CreatedAt, UpdatedAt)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            OleDbParameter[] p = new OleDbParameter[]
            {
                DatabaseManager.CreateParameter("@Code", emp.Code),
                DatabaseManager.CreateParameter("@Name", emp.Name),
                DatabaseManager.CreateParameter("@JobTitle", emp.JobTitle),
                DatabaseManager.CreateParameter("@DepartmentID", emp.DepartmentID),
                DatabaseManager.CreateParameter("@HireDate", emp.HireDate),
                DatabaseManager.CreateParameter("@StartDate", emp.StartDate),
                DatabaseManager.CreateParameter("@BirthDate", emp.BirthDate),
                DatabaseManager.CreateParameter("@NationalID", emp.NationalID),
                DatabaseManager.CreateParameter("@Status", emp.Status),
                DatabaseManager.CreateParameter("@Phone", emp.Phone),
                DatabaseManager.CreateParameter("@Email", emp.Email),
                DatabaseManager.CreateParameter("@Address", emp.Address),
                DatabaseManager.CreateParameter("@Notes", emp.Notes)
            };
            return DatabaseManager.ExecuteInsertGetIdentity(query, p);
        }

        /// <summary>
        /// تحديث بيانات موظف
        /// </summary>
        public static bool UpdateEmployee(EmployeeModel emp)
        {
            string query = @"UPDATE Employees SET Code=?, Name=?, JobTitle=?, DepartmentID=?, HireDate=?, 
                            StartDate=?, BirthDate=?, NationalID=?, Status=?, Phone=?, Email=?, Address=?, 
                            Notes=?, UpdatedAt=NOW() WHERE ID=?";
            OleDbParameter[] p = new OleDbParameter[]
            {
                DatabaseManager.CreateParameter("@Code", emp.Code),
                DatabaseManager.CreateParameter("@Name", emp.Name),
                DatabaseManager.CreateParameter("@JobTitle", emp.JobTitle),
                DatabaseManager.CreateParameter("@DepartmentID", emp.DepartmentID),
                DatabaseManager.CreateParameter("@HireDate", emp.HireDate),
                DatabaseManager.CreateParameter("@StartDate", emp.StartDate),
                DatabaseManager.CreateParameter("@BirthDate", emp.BirthDate),
                DatabaseManager.CreateParameter("@NationalID", emp.NationalID),
                DatabaseManager.CreateParameter("@Status", emp.Status),
                DatabaseManager.CreateParameter("@Phone", emp.Phone),
                DatabaseManager.CreateParameter("@Email", emp.Email),
                DatabaseManager.CreateParameter("@Address", emp.Address),
                DatabaseManager.CreateParameter("@Notes", emp.Notes),
                DatabaseManager.CreateParameter("@ID", emp.ID)
            };
            int rows = DatabaseManager.ExecuteNonQuery(query, p);
            return rows > 0;
        }

        /// <summary>
        /// حذف موظف (نقل إلى سلة المهملات)
        /// </summary>
        public static bool DeleteEmployee(int employeeId, string trashedBy)
        {
            // جلب بيانات الموظف كـ JSON
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM Employees WHERE ID=?", DatabaseManager.CreateParameter("@id", employeeId));
            if (dt.Rows.Count == 0) return false;
            string jsonData = Newtonsoft.Json.JsonConvert.SerializeObject(dt.Rows[0]);
            // إدراج في Trash
            string insertTrash = "INSERT INTO Trash (RecordType, OriginalID, Data, TrashedBy, TrashedAt) VALUES (?, ?, ?, ?, NOW())";
            DatabaseManager.ExecuteNonQuery(insertTrash,
                DatabaseManager.CreateParameter("@type", Constants.TrashTypeEmployee),
                DatabaseManager.CreateParameter("@origId", employeeId),
                DatabaseManager.CreateParameter("@data", jsonData),
                DatabaseManager.CreateParameter("@user", trashedBy));
            // حذف من جدول الموظفين (سيتم حذف الإجازات المرتبطة؟ حسب القاعدة يجب حذفها أيضاً)
            string deleteEmp = "DELETE FROM Employees WHERE ID=?";
            DatabaseManager.ExecuteNonQuery(deleteEmp, DatabaseManager.CreateParameter("@id", employeeId));
            return true;
        }

        #endregion

        #region العمليات على الإجازات المرضية

        public static DataTable GetAllSickLeaves()
        {
            string query = @"SELECT sl.*, (SELECT COUNT(*) FROM Attachments WHERE SickLeaveID=sl.ID) AS AttachmentsCount
                             FROM SickLeaves sl ORDER BY sl.ID DESC";
            return DatabaseManager.ExecuteQuery(query);
        }

        public static DataTable SearchSickLeaves(string keyword, string status, int? departmentId, string monthYear)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(@"SELECT sl.*, (SELECT COUNT(*) FROM Attachments WHERE SickLeaveID=sl.ID) AS AttachmentsCount 
                        FROM SickLeaves sl WHERE 1=1");
            List<object> paramList = new List<object>();
            if (!string.IsNullOrEmpty(keyword))
            {
                sb.Append(" AND (sl.EmpName LIKE ? OR sl.EmpCode LIKE ? OR sl.Diagnosis LIKE ? OR sl.DecisionNo LIKE ?)");
                string kw = $"%{keyword}%";
                paramList.Add(kw); paramList.Add(kw); paramList.Add(kw); paramList.Add(kw);
            }
            if (!string.IsNullOrEmpty(status) && status != "الكل")
                sb.Append(" AND sl.Status = ?"); paramList.Add(status);
            if (departmentId.HasValue && departmentId > 0)
            {
                sb.Append(" AND sl.DepartmentID = ?"); paramList.Add(departmentId);
            }
            if (!string.IsNullOrEmpty(monthYear))
            {
                sb.Append(" AND FORMAT(sl.DateFrom, 'yyyy-mm') = ?"); paramList.Add(monthYear);
            }
            sb.Append(" ORDER BY sl.ID DESC");

            OleDbParameter[] pars = new OleDbParameter[paramList.Count];
            for (int i = 0; i < paramList.Count; i++) pars[i] = DatabaseManager.CreateParameter($"@p{i}", paramList[i]);
            return DatabaseManager.ExecuteQuery(sb.ToString(), pars);
        }

        public static int AddSickLeave(SickLeaveModel sl)
        {
            string query = @"INSERT INTO SickLeaves (EmployeeID, EmpCode, EmpName, EmpJob, DepartmentName, 
                            DateFrom, DateTo, Days, Diagnosis, DecisionNo, Issuer, Doctor, Status, Notes, AddedBy, CreatedAt, UpdatedAt)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            int days = (sl.DateTo - sl.DateFrom).Days + 1;
            OleDbParameter[] p = new OleDbParameter[]
            {
                DatabaseManager.CreateParameter("@EmpID", sl.EmployeeID),
                DatabaseManager.CreateParameter("@EmpCode", sl.EmpCode),
                DatabaseManager.CreateParameter("@EmpName", sl.EmpName),
                DatabaseManager.CreateParameter("@EmpJob", sl.EmpJob),
                DatabaseManager.CreateParameter("@DeptName", sl.DepartmentName),
                DatabaseManager.CreateParameter("@DateFrom", sl.DateFrom),
                DatabaseManager.CreateParameter("@DateTo", sl.DateTo),
                DatabaseManager.CreateParameter("@Days", days),
                DatabaseManager.CreateParameter("@Diag", sl.Diagnosis),
                DatabaseManager.CreateParameter("@DecNo", sl.DecisionNo),
                DatabaseManager.CreateParameter("@Issuer", sl.Issuer),
                DatabaseManager.CreateParameter("@Doctor", sl.Doctor),
                DatabaseManager.CreateParameter("@Status", sl.Status),
                DatabaseManager.CreateParameter("@Notes", sl.Notes),
                DatabaseManager.CreateParameter("@AddedBy", sl.AddedBy)
            };
            return DatabaseManager.ExecuteInsertGetIdentity(query, p);
        }

        public static bool UpdateSickLeave(SickLeaveModel sl)
        {
            int days = (sl.DateTo - sl.DateFrom).Days + 1;
            string query = @"UPDATE SickLeaves SET EmployeeID=?, EmpCode=?, EmpName=?, EmpJob=?, DepartmentName=?,
                            DateFrom=?, DateTo=?, Days=?, Diagnosis=?, DecisionNo=?, Issuer=?, Doctor=?, Status=?, 
                            Notes=?, AddedBy=?, UpdatedAt=NOW() WHERE ID=?";
            OleDbParameter[] p = new OleDbParameter[]
            {
                DatabaseManager.CreateParameter("@EmpID", sl.EmployeeID),
                DatabaseManager.CreateParameter("@EmpCode", sl.EmpCode),
                DatabaseManager.CreateParameter("@EmpName", sl.EmpName),
                DatabaseManager.CreateParameter("@EmpJob", sl.EmpJob),
                DatabaseManager.CreateParameter("@DeptName", sl.DepartmentName),
                DatabaseManager.CreateParameter("@DateFrom", sl.DateFrom),
                DatabaseManager.CreateParameter("@DateTo", sl.DateTo),
                DatabaseManager.CreateParameter("@Days", days),
                DatabaseManager.CreateParameter("@Diag", sl.Diagnosis),
                DatabaseManager.CreateParameter("@DecNo", sl.DecisionNo),
                DatabaseManager.CreateParameter("@Issuer", sl.Issuer),
                DatabaseManager.CreateParameter("@Doctor", sl.Doctor),
                DatabaseManager.CreateParameter("@Status", sl.Status),
                DatabaseManager.CreateParameter("@Notes", sl.Notes),
                DatabaseManager.CreateParameter("@AddedBy", sl.AddedBy),
                DatabaseManager.CreateParameter("@ID", sl.ID)
            };
            return DatabaseManager.ExecuteNonQuery(query, p) > 0;
        }

        public static bool DeleteSickLeave(int slId, string trashedBy)
        {
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM SickLeaves WHERE ID=?", DatabaseManager.CreateParameter("@id", slId));
            if (dt.Rows.Count == 0) return false;
            string jsonData = Newtonsoft.Json.JsonConvert.SerializeObject(dt.Rows[0]);
            string insertTrash = "INSERT INTO Trash (RecordType, OriginalID, Data, TrashedBy, TrashedAt) VALUES (?, ?, ?, ?, NOW())";
            DatabaseManager.ExecuteNonQuery(insertTrash,
                DatabaseManager.CreateParameter("@type", Constants.TrashTypeSickLeave),
                DatabaseManager.CreateParameter("@origId", slId),
                DatabaseManager.CreateParameter("@data", jsonData),
                DatabaseManager.CreateParameter("@user", trashedBy));
            string delete = "DELETE FROM SickLeaves WHERE ID=?";
            DatabaseManager.ExecuteNonQuery(delete, DatabaseManager.CreateParameter("@id", slId));
            return true;
        }

        #endregion

        #region الأقسام

        public static DataTable GetAllDepartments()
        {
            return DatabaseManager.ExecuteQuery("SELECT * FROM Departments ORDER BY Name");
        }

        public static bool AddDepartment(string name, string description)
        {
            string query = "INSERT INTO Departments (Name, Description, CreatedAt, UpdatedAt) VALUES (?, ?, NOW(), NOW())";
            try
            {
                DatabaseManager.ExecuteNonQuery(query, 
                    DatabaseManager.CreateParameter("@name", name),
                    DatabaseManager.CreateParameter("@desc", description));
                return true;
            }
            catch { return false; }
        }

        public static bool UpdateDepartment(int id, string name, string description)
        {
            string query = "UPDATE Departments SET Name=?, Description=?, UpdatedAt=NOW() WHERE ID=?";
            return DatabaseManager.ExecuteNonQuery(query,
                DatabaseManager.CreateParameter("@name", name),
                DatabaseManager.CreateParameter("@desc", description),
                DatabaseManager.CreateParameter("@id", id)) > 0;
        }

        public static bool DeleteDepartment(int id)
        {
            // التحقق من عدم وجود موظفين مرتبطين بهذا القسم
            long count = (long)DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM Employees WHERE DepartmentID=?", DatabaseManager.CreateParameter("@id", id));
            if (count > 0)
            {
                MessageBox.Show("لا يمكن حذف القسم لأنه يحتوي على موظفين مرتبطين به.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return DatabaseManager.ExecuteNonQuery("DELETE FROM Departments WHERE ID=?", DatabaseManager.CreateParameter("@id", id)) > 0;
        }

        #endregion

        #region المستخدمين

        public static DataTable GetAllUsers()
        {
            return DatabaseManager.ExecuteQuery("SELECT ID, Username, Role, IsActive, CreatedAt, LastLogin FROM Users ORDER BY Username");
        }

        public static bool AddUser(string username, string passwordHash, string passwordSalt, string role)
        {
            string query = "INSERT INTO Users (Username, PasswordHash, PasswordSalt, Role, IsActive, CreatedAt) VALUES (?, ?, ?, ?, ?, NOW())";
            return DatabaseManager.ExecuteNonQuery(query,
                DatabaseManager.CreateParameter("@user", username),
                DatabaseManager.CreateParameter("@hash", passwordHash),
                DatabaseManager.CreateParameter("@salt", passwordSalt),
                DatabaseManager.CreateParameter("@role", role),
                DatabaseManager.CreateParameter("@active", true)) > 0;
        }

        public static bool UpdateUser(int id, string role, bool isActive, string newPasswordHash = null, string newPasswordSalt = null)
        {
            if (!string.IsNullOrEmpty(newPasswordHash))
            {
                string query = "UPDATE Users SET Role=?, IsActive=?, PasswordHash=?, PasswordSalt=?, LastLogin=LastLogin WHERE ID=?";
                return DatabaseManager.ExecuteNonQuery(query,
                    DatabaseManager.CreateParameter("@role", role),
                    DatabaseManager.CreateParameter("@active", isActive),
                    DatabaseManager.CreateParameter("@hash", newPasswordHash),
                    DatabaseManager.CreateParameter("@salt", newPasswordSalt),
                    DatabaseManager.CreateParameter("@id", id)) > 0;
            }
            else
            {
                string query = "UPDATE Users SET Role=?, IsActive=?, LastLogin=LastLogin WHERE ID=?";
                return DatabaseManager.ExecuteNonQuery(query,
                    DatabaseManager.CreateParameter("@role", role),
                    DatabaseManager.CreateParameter("@active", isActive),
                    DatabaseManager.CreateParameter("@id", id)) > 0;
            }
        }

        public static bool DeleteUser(int id)
        {
            if (id == GlobalState.CurrentUser.ID)
            {
                MessageBox.Show("لا يمكنك حذف حساب المستخدم الحالي نفسه.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return DatabaseManager.ExecuteNonQuery("DELETE FROM Users WHERE ID=?", DatabaseManager.CreateParameter("@id", id)) > 0;
        }

        public static UserModel GetUserByUsername(string username)
        {
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM Users WHERE Username=?", DatabaseManager.CreateParameter("@user", username));
            if (dt.Rows.Count == 0) return null;
            DataRow r = dt.Rows[0];
            return new UserModel
            {
                ID = Convert.ToInt32(r["ID"]),
                Username = r["Username"].ToString(),
                PasswordHash = r["PasswordHash"].ToString(),
                PasswordSalt = r["PasswordSalt"].ToString(),
                Role = r["Role"].ToString(),
                IsActive = Convert.ToBoolean(r["IsActive"]),
                CreatedAt = Convert.ToDateTime(r["CreatedAt"]),
                LastLogin = r["LastLogin"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(r["LastLogin"])
            };
        }

        public static bool UpdateLastLogin(int userId)
        {
            return DatabaseManager.ExecuteNonQuery("UPDATE Users SET LastLogin=NOW() WHERE ID=?", DatabaseManager.CreateParameter("@id", userId)) > 0;
        }

        #endregion

        #region سلة المهملات

        public static DataTable GetAllTrashItems()
        {
            return DatabaseManager.ExecuteQuery("SELECT * FROM Trash ORDER BY TrashedAt DESC");
        }

        public static bool RestoreFromTrash(int trashId)
        {
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId));
            if (dt.Rows.Count == 0) return false;
            DataRow row = dt.Rows[0];
            string type = row["RecordType"].ToString();
            string jsonData = row["Data"].ToString();
            int originalId = Convert.ToInt32(row["OriginalID"]);
            // استخدام Newtonsoft.Json لتحويل JSON إلى DataRow (أو نموذج مناسب)
            // سنقوم بإعادة الإدراج في الجدول الأصلي
            if (type == Constants.TrashTypeEmployee)
            {
                // نحتاج إلى تحويل JSON إلى كائن ثم إدراجه
                // سننفذ هذا في طبقة أعلى لتجنب تعقيد إضافي.
            }
            else if (type == Constants.TrashTypeSickLeave)
            {
                // نفس الشيء
            }
            // حذف من Trash بعد الاستعادة
            DatabaseManager.ExecuteNonQuery("DELETE FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId));
            return true;
        }

        public static bool PermanentDeleteTrash(int trashId)
        {
            return DatabaseManager.ExecuteNonQuery("DELETE FROM Trash WHERE ID=?", DatabaseManager.CreateParameter("@id", trashId)) > 0;
        }

        public static bool EmptyTrash()
        {
            return DatabaseManager.ExecuteNonQuery("DELETE FROM Trash") > 0;
        }

        #endregion
    }
}