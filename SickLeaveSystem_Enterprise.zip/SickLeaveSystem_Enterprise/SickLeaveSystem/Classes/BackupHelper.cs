using System;
using System.IO;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    public static class BackupHelper
    {
        /// <summary>
        /// إنشاء نسخة احتياطية من قاعدة البيانات (نسخ ملف MDB)
        /// </summary>
        public static bool CreateBackup(string backupFolderPath = null)
        {
            try
            {
                if (string.IsNullOrEmpty(backupFolderPath))
                    backupFolderPath = GlobalState.BackupPath;
                if (!Directory.Exists(backupFolderPath))
                    Directory.CreateDirectory(backupFolderPath);

                string sourceDb = DatabaseManager.ConnectionString.Split(';')[1].Split('=')[1]; // استخراج المسار الفعلي
                string fileName = Path.GetFileNameWithoutExtension(sourceDb);
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string destFile = Path.Combine(backupFolderPath, $"{fileName}_Backup_{timestamp}.mdb");

                File.Copy(sourceDb, destFile, true);

                // تسجيل العملية
                AuditHelper.Log(Constants.AuditActionBackup, "Database", 0, $"نسخة احتياطية: {destFile}");
                GlobalState.LastBackupDate = DateTime.Now;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل إنشاء النسخة الاحتياطية: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// استعادة قاعدة البيانات من نسخة احتياطية (تتطلب إغلاق الاتصالات)
        /// </summary>
        public static bool RestoreBackup(string backupFilePath)
        {
            if (!File.Exists(backupFilePath))
            {
                MessageBox.Show("ملف النسخة الاحتياطية غير موجود.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            try
            {
                string currentDb = DatabaseManager.ConnectionString.Split(';')[1].Split('=')[1];
                // نسخ الملف الاحتياطي فوق الملف الحالي (يتطلب عدم وجود اتصال مفتوح)
                File.Copy(backupFilePath, currentDb, true);
                AuditHelper.Log(Constants.AuditActionRestoreDB, "Database", 0, $"استعادة قاعدة البيانات من {backupFilePath}");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل استعادة قاعدة البيانات: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// جلب قائمة بالنسخ الاحتياطية المتاحة
        /// </summary>
        public static string[] GetBackupFiles(string backupFolderPath = null)
        {
            if (string.IsNullOrEmpty(backupFolderPath))
                backupFolderPath = GlobalState.BackupPath;
            if (!Directory.Exists(backupFolderPath))
                return new string[0];
            return Directory.GetFiles(backupFolderPath, "*.mdb");
        }

        /// <summary>
        /// حذف النسخ الاحتياطية الأقدم من عدد معين من الأيام
        /// </summary>
        public static void CleanOldBackups(int daysToKeep = 30)
        {
            string[] backups = GetBackupFiles();
            DateTime cutoff = DateTime.Now.AddDays(-daysToKeep);
            foreach (string file in backups)
            {
                if (File.GetCreationTime(file) < cutoff)
                    File.Delete(file);
            }
        }
    }
}