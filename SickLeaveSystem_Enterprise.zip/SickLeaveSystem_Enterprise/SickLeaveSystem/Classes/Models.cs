using System;
using System.Collections.Generic;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// نموذج بيانات الموظف
    /// </summary>
    public class EmployeeModel
    {
        public int ID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string JobTitle { get; set; }
        public int? DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public DateTime? HireDate { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? BirthDate { get; set; }
        public string NationalID { get; set; }
        public string Status { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string Notes { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    /// <summary>
    /// نموذج بيانات الإجازة المرضية
    /// </summary>
    public class SickLeaveModel
    {
        public int ID { get; set; }
        public int EmployeeID { get; set; }
        public string EmpCode { get; set; }
        public string EmpName { get; set; }
        public string EmpJob { get; set; }
        public string DepartmentName { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public int Days { get; set; }
        public string Diagnosis { get; set; }
        public string DecisionNo { get; set; }
        public string Issuer { get; set; }
        public string Doctor { get; set; }
        public string Status { get; set; }
        public string Notes { get; set; }
        public string AddedBy { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    /// <summary>
    /// نموذج بيانات المستخدم
    /// </summary>
    public class UserModel
    {
        public int ID { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string PasswordSalt { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastLogin { get; set; }
    }

    /// <summary>
    /// نموذج بيانات القسم
    /// </summary>
    public class DepartmentModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    /// <summary>
    /// نموذج بيانات المرفقات
    /// </summary>
    public class AttachmentModel
    {
        public int ID { get; set; }
        public int SickLeaveID { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public long FileSize { get; set; }
        public string FileType { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>
    /// نموذج سلة المهملات
    /// </summary>
    public class TrashModel
    {
        public int ID { get; set; }
        public string RecordType { get; set; }
        public int OriginalID { get; set; }
        public string Data { get; set; }  // JSON serialized data
        public string TrashedBy { get; set; }
        public DateTime TrashedAt { get; set; }
    }

    /// <summary>
    /// نموذج سجل التدقيق
    /// </summary>
    public class AuditLogModel
    {
        public int ID { get; set; }
        public string Action { get; set; }
        public string TableName { get; set; }
        public int RecordID { get; set; }
        public string Description { get; set; }
        public string Username { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>
    /// نموذج إعدادات النظام
    /// </summary>
    public class SystemSettingModel
    {
        public int ID { get; set; }
        public string SettingKey { get; set; }
        public string SettingValue { get; set; }
        public string Description { get; set; }
    }
}