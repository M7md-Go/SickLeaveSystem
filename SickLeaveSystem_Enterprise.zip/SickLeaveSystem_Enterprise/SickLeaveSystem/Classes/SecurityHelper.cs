using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// دالة مساعدة للتشفير وإدارة الأمان
    /// </summary>
    public static class SecurityHelper
    {
        private static readonly RandomNumberGenerator rng = RandomNumberGenerator.Create();

        /// <summary>
        /// إنشاء ملح عشوائي (Salt) بطول محدد
        /// </summary>
        public static string GenerateSalt(int length = 32)
        {
            byte[] saltBytes = new byte[length];
            rng.GetBytes(saltBytes);
            return Convert.ToBase64String(saltBytes);
        }

        /// <summary>
        /// تشفير كلمة المرور باستخدام PBKDF2 (SHA256)
        /// </summary>
        public static string HashPassword(string password, string salt)
        {
            byte[] saltBytes = Convert.FromBase64String(salt);
            using (Rfc2898DeriveBytes pbkdf2 = new Rfc2898DeriveBytes(password, saltBytes, 10000))
            {
                byte[] hashBytes = pbkdf2.GetBytes(32);
                return Convert.ToBase64String(hashBytes);
            }
        }

        /// <summary>
        /// التحقق من صحة كلمة المرور
        /// </summary>
        public static bool VerifyPassword(string enteredPassword, string storedHash, string storedSalt)
        {
            string computedHash = HashPassword(enteredPassword, storedSalt);
            return computedHash == storedHash;
        }

        /// <summary>
        /// التحقق من صلاحيات المستخدم الحالي
        /// </summary>
        public static bool HasAccess(string requiredRole)
        {
            if (GlobalState.CurrentUser == null) return false;
            if (GlobalState.CurrentUser.Role == Constants.RoleAdmin) return true;
            if (requiredRole == Constants.RoleAdmin) return false;
            if (requiredRole == Constants.RoleHR && GlobalState.CurrentUser.Role == Constants.RoleHR) return true;
            if (requiredRole == Constants.RoleViewer) return true; // viewer يمكنه عرض كل شيء
            return false;
        }

        /// <summary>
        /// التحقق من صلاحية التعديل والحذف
        /// </summary>
        public static bool CanEdit()
        {
            return HasAccess(Constants.RoleAdmin) || HasAccess(Constants.RoleHR);
        }

        public static bool CanDelete()
        {
            return HasAccess(Constants.RoleAdmin) || HasAccess(Constants.RoleHR);
        }

        /// <summary>
        /// التحقق من قوة كلمة المرور
        /// </summary>
        public static bool IsStrongPassword(string password, int minLength = 6)
        {
            if (string.IsNullOrEmpty(password) || password.Length < minLength)
                return false;
            // يفضل وجود حرف كبير وحرف صغير ورقم (اختياري للبساطة)
            bool hasUpper = Regex.IsMatch(password, @"[A-Z]");
            bool hasLower = Regex.IsMatch(password, @"[a-z]");
            bool hasDigit = Regex.IsMatch(password, @"\d");
            return hasUpper && hasLower && hasDigit;
        }

        /// <summary>
        /// تشفير نص بسيط (Base64) - للاستخدام في بعض الإعدادات
        /// </summary>
        public static string EncryptText(string plainText, string key)
        {
            // استخدام XOR بسيط مع مفتاح (لأغراض بسيطة فقط)
            byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            for (int i = 0; i < plainBytes.Length; i++)
                plainBytes[i] ^= keyBytes[i % keyBytes.Length];
            return Convert.ToBase64String(plainBytes);
        }

        public static string DecryptText(string cipherBase64, string key)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherBase64);
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);
            for (int i = 0; i < cipherBytes.Length; i++)
                cipherBytes[i] ^= keyBytes[i % keyBytes.Length];
            return Encoding.UTF8.GetString(cipherBytes);
        }
    }
}