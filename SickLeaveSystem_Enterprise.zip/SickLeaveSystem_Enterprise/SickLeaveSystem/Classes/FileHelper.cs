using System;
using System.IO;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    public static class FileHelper
    {
        /// <summary>
        /// نسخ ملف إلى مجلد المرفقات وإرجاع المسار الجديد
        /// </summary>
        public static string CopyAttachmentFile(string sourceFilePath, int sickLeaveId)
        {
            if (!Directory.Exists(GlobalState.AttachmentsPath))
                Directory.CreateDirectory(GlobalState.AttachmentsPath);
            string fileName = Path.GetFileName(sourceFilePath);
            string newFileName = $"{sickLeaveId}_{DateTime.Now.Ticks}_{fileName}";
            string destPath = Path.Combine(GlobalState.AttachmentsPath, newFileName);
            File.Copy(sourceFilePath, destPath, true);
            return destPath;
        }

        /// <summary>
        /// حذف ملف مرفق
        /// </summary>
        public static bool DeleteAttachmentFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);
                return true;
            }
            catch { return false; }
        }

        /// <summary>
        /// فتح ملف باستخدام البرنامج الافتراضي
        /// </summary>
        public static void OpenFile(string filePath)
        {
            if (File.Exists(filePath))
                System.Diagnostics.Process.Start(filePath);
            else
                MessageBox.Show("الملف غير موجود.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}