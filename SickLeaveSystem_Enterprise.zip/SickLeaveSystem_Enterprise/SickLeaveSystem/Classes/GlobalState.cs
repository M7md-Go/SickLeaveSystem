using System;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// تخزين الحالة العامة للتطبيق والمستخدم الحالي والإعدادات
    /// </summary>
    public static class GlobalState
    {
        private static UserModel _currentUser = null;
        public static UserModel CurrentUser
        {
            get { return _currentUser; }
            set { _currentUser = value; }
        }

        public static string AppTitle
        {
            get { return "نظام إدارة الإجازات المرضية - Enterprise"; }
        }

        // مجلد التطبيق
        public static string AppPath
        {
            get { return Application.StartupPath; }
        }

        // مجلد المرفقات
        public static string AttachmentsPath
        {
            get { return System.IO.Path.Combine(AppPath, "Attachments"); }
        }

        // مجلد النسخ الاحتياطية
        public static string BackupPath
        {
            get
            {
                string path = System.Configuration.ConfigurationManager.AppSettings["BackupPath"];
                if (string.IsNullOrEmpty(path))
                    path = System.IO.Path.Combine(AppPath, "Backups");
                return path;
            }
        }

        // آخر نسخة احتياطية
        public static DateTime? LastBackupDate { get; set; }

        // إعداد النظام: هل يتم النسخ الاحتياطي تلقائياً
        public static bool AutoBackupEnabled
        {
            get
            {
                string val = GetSetting(Constants.SettingAutoBackup);
                return val == "True" || val == "true";
            }
        }

        /// <summary>
        /// الحصول على قيمة إعداد من جدول SystemSettings
        /// </summary>
        public static string GetSetting(string key, string defaultValue = "")
        {
            try
            {
                object result = DatabaseManager.ExecuteScalar("SELECT SettingValue FROM SystemSettings WHERE SettingKey=?", DatabaseManager.CreateParameter("@key", key));
                if (result != null && result != DBNull.Value)
                    return result.ToString();
            }
            catch { }
            return defaultValue;
        }

        /// <summary>
        /// حفظ قيمة إعداد
        /// </summary>
        public static void SetSetting(string key, string value)
        {
            // التحقق من وجود المفتاح
            object exists = DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SystemSettings WHERE SettingKey=?", DatabaseManager.CreateParameter("@key", key));
            if (Convert.ToInt32(exists) > 0)
            {
                DatabaseManager.ExecuteNonQuery("UPDATE SystemSettings SET SettingValue=? WHERE SettingKey=?", 
                    DatabaseManager.CreateParameter("@val", value),
                    DatabaseManager.CreateParameter("@key", key));
            }
            else
            {
                DatabaseManager.ExecuteNonQuery("INSERT INTO SystemSettings (SettingKey, SettingValue) VALUES (?, ?)",
                    DatabaseManager.CreateParameter("@key", key),
                    DatabaseManager.CreateParameter("@val", value));
            }
        }
    }
}