using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    public static class ExportHelper
    {
        /// <summary>
        /// تصدير DataTable إلى ملف CSV
        /// </summary>
        public static bool ExportToCSV(DataTable dt, string fileName, bool includeHeader = true)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                if (includeHeader)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        sb.Append(dt.Columns[i].ColumnName);
                        if (i < dt.Columns.Count - 1) sb.Append(",");
                    }
                    sb.AppendLine();
                }
                foreach (DataRow row in dt.Rows)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        string value = row[i].ToString();
                        if (value.Contains(",") || value.Contains("\""))
                            value = "\"" + value.Replace("\"", "\"\"") + "\"";
                        sb.Append(value);
                        if (i < dt.Columns.Count - 1) sb.Append(",");
                    }
                    sb.AppendLine();
                }
                File.WriteAllText(fileName, sb.ToString(), Encoding.UTF8);
                return true;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("خطأ في التصدير: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// تصدير DataTable إلى ملف Excel (HTML Table بسيط)
        /// </summary>
        public static bool ExportToExcel(DataTable dt, string fileName)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("<html><head><meta charset='utf-8'><title>تقرير</title></head><body>");
                sb.AppendLine("<table border='1' dir='rtl'>");
                // Header
                sb.AppendLine("<tr>");
                foreach (DataColumn col in dt.Columns)
                    sb.AppendLine($"<th>{col.ColumnName}</th>");
                sb.AppendLine("</tr>");
                // Rows
                foreach (DataRow row in dt.Rows)
                {
                    sb.AppendLine("<tr>");
                    foreach (DataColumn col in dt.Columns)
                        sb.AppendLine($"<td>{row[col].ToString()}</td>");
                    sb.AppendLine("</tr>");
                }
                sb.AppendLine("</table></body></html>");
                File.WriteAllText(fileName, sb.ToString(), Encoding.UTF8);
                return true;
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("خطأ في التصدير: " + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// عرض مربع حوار حفظ الملف وتصدير CSV
        /// </summary>
        public static void ExportDataGridViewToCSV(DataGridView dgv, string defaultName)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            sfd.FileName = defaultName;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                DataTable dt = ((DataTable)dgv.DataSource);
                if (dt == null)
                {
                    // إذا كان DataGridView مربوطاً بـ DataTable
                    dt = new DataTable();
                    foreach (DataGridViewColumn col in dgv.Columns)
                        dt.Columns.Add(col.HeaderText);
                    foreach (DataGridViewRow row in dgv.Rows)
                    {
                        if (row.IsNewRow) continue;
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < dgv.Columns.Count; i++)
                            dr[i] = row.Cells[i].Value?.ToString();
                        dt.Rows.Add(dr);
                    }
                }
                ExportToCSV(dt, sfd.FileName);
                MessageBox.Show("تم التصدير بنجاح", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}