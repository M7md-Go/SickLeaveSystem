using System;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace SickLeaveSystem.Classes
{
    public static class ReportHelper
    {
        private static DataTable reportData;
        private static string reportTitle;
        private static int currentRowIndex;
        private static Font printFont;
        private static float yPos;
        private static float leftMargin;
        private static float topMargin;
        private static int linesPerPage;

        /// <summary>
        /// طباعة تقرير من DataTable
        /// </summary>
        public static void PrintReport(DataTable data, string title)
        {
            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("لا توجد بيانات للطباعة.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            reportData = data;
            reportTitle = title;
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintPageHandler);
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = pd;
            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                currentRowIndex = 0;
                pd.Print();
            }
        }

        private static void PrintPageHandler(object sender, PrintPageEventArgs e)
        {
            printFont = new Font("Arial", 10);
            leftMargin = e.MarginBounds.Left;
            topMargin = e.MarginBounds.Top;
            yPos = topMargin;
            linesPerPage = (int)(e.MarginBounds.Height / printFont.GetHeight(e.Graphics));

            // طباعة العنوان
            Font titleFont = new Font("Arial", 16, FontStyle.Bold);
            e.Graphics.DrawString(reportTitle, titleFont, Brushes.Black, leftMargin, yPos);
            yPos += titleFont.GetHeight(e.Graphics) + 10;

            // طباعة أسماء الأعمدة
            Font headerFont = new Font("Arial", 9, FontStyle.Bold);
            float xPos = leftMargin;
            for (int i = 0; i < reportData.Columns.Count; i++)
            {
                e.Graphics.DrawString(reportData.Columns[i].ColumnName, headerFont, Brushes.Black, xPos, yPos);
                xPos += 100; // تبسيط
            }
            yPos += headerFont.GetHeight(e.Graphics) + 5;

            // طباعة الصفوف
            while (currentRowIndex < reportData.Rows.Count && yPos < e.MarginBounds.Bottom - printFont.GetHeight(e.Graphics))
            {
                DataRow row = reportData.Rows[currentRowIndex];
                xPos = leftMargin;
                for (int i = 0; i < reportData.Columns.Count; i++)
                {
                    string value = row[i].ToString();
                    e.Graphics.DrawString(value, printFont, Brushes.Black, xPos, yPos);
                    xPos += 100;
                }
                yPos += printFont.GetHeight(e.Graphics);
                currentRowIndex++;
            }

            if (currentRowIndex < reportData.Rows.Count)
                e.HasMorePages = true;
            else
                e.HasMorePages = false;
        }

        /// <summary>
        /// معاينة التقرير قبل الطباعة
        /// </summary>
        public static void PrintPreview(DataTable data, string title)
        {
            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("لا توجد بيانات للطباعة.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            reportData = data;
            reportTitle = title;
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(PrintPageHandler);
            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = pd;
            ppd.ShowDialog();
        }
    }
}