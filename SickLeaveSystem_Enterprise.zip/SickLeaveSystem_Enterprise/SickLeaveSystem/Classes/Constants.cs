using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SickLeaveSystem.Classes
{
    /// <summary>
    /// الثوابت العامة المستخدمة في جميع أنحاء النظام
    /// </summary>
    public static class Constants
    {
        // أدوار المستخدمين
        public const string RoleAdmin = "admin";
        public const string RoleHR = "hr";
        public const string RoleViewer = "viewer";

        // حالات الموظف
        public const string EmployeeStatusActive = "active";
        public const string EmployeeStatusInactive = "inactive";
        public const string EmployeeStatusOnLeave = "onleave";

        // حالات الإجازة المرضية
        public const string SickLeaveStatusReview = "review";
        public const string SickLeaveStatusApproved = "approved";
        public const string SickLeaveStatusRejected = "rejected";
        public const string SickLeaveStatusExpired = "expired";

        // أنواع السجلات في سلة المهملات
        public const string TrashTypeEmployee = "employee";
        public const string TrashTypeSickLeave = "sickleave";

        // أسماء الجداول
        public const string TableEmployees = "Employees";
        public const string TableSickLeaves = "SickLeaves";
        public const string TableAttachments = "Attachments";
        public const string TableUsers = "Users";
        public const string TableAuditLog = "AuditLog";
        public const string TableTrash = "Trash";
        public const string TableDepartments = "Departments";
        public const string TableSystemSettings = "SystemSettings";

        // الأحداث المسجلة في سجل التدقيق
        public const string AuditActionInsert = "إضافة";
        public const string AuditActionUpdate = "تعديل";
        public const string AuditActionDelete = "حذف";
        public const string AuditActionRestore = "استعادة";
        public const string AuditActionLogin = "تسجيل دخول";
        public const string AuditActionLogout = "تسجيل خروج";
        public const string AuditActionExport = "تصدير بيانات";
        public const string AuditActionBackup = "نسخ احتياطي";
        public const string AuditActionRestoreDB = "استعادة قاعدة البيانات";

        // إعدادات النظام
        public const string SettingCompanyName = "CompanyName";
        public const string SettingAutoBackup = "AutoBackup";
        public const string SettingBackupPath = "BackupPath";
        public const string SettingDefaultPasswordLength = "DefaultPasswordLength";
    }
}