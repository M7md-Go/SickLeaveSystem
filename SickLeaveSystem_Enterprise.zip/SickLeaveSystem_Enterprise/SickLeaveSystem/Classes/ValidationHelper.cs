using System;
using System.Text.RegularExpressions;

namespace SickLeaveSystem.Classes
{
    public static class ValidationHelper
    {
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrEmpty(email)) return true; // البريد اختياري
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrEmpty(phone)) return true;
            return Regex.IsMatch(phone, @"^(\+?20|0)?1[0125]\d{8}$");
        }

        public static bool IsValidNationalID(string nationalId)
        {
            if (string.IsNullOrEmpty(nationalId)) return true;
            if (nationalId.Length != 14) return false;
            return Regex.IsMatch(nationalId, @"^\d{14}$");
        }

        public static bool IsValidDateRange(DateTime from, DateTime to)
        {
            return from <= to;
        }

        public static int CalculateDays(DateTime from, DateTime to)
        {
            if (from > to) return 0;
            return (to - from).Days + 1;
        }
    }
}