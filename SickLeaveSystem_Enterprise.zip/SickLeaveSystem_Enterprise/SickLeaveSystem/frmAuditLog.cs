using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmAuditLog : Form
    {
        private DataGridView dgvAudit;
        private TextBox txtSearch;
        private DateTimePicker dtpFrom, dtpTo;
        private Button btnSearch, btnExport;
        private Label lblTotal;

        public frmAuditLog()
        {
            InitializeComponent();
            LoadAuditLog();
        }

        private void InitializeComponent()
        {
            this.Text = "سجل التدقيق";
            this.Size = new Size(1100, 550);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // لوحة البحث
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Height = 55;
            searchPanel.BackColor = Color.FromArgb(13, 24, 40);
            searchPanel.Padding = new Padding(8);

            Label lblSearch = new Label();
            lblSearch.Text = "بحث (مستخدم، وصف):";
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(10, 15);
            lblSearch.AutoSize = true;

            txtSearch = new TextBox();
            txtSearch.Location = new Point(160, 13);
            txtSearch.Width = 200;
            txtSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtSearch.ForeColor = Color.White;
            txtSearch.TextChanged += TxtSearch_TextChanged;

            Label lblFrom = new Label();
            lblFrom.Text = "من تاريخ:";
            lblFrom.ForeColor = Color.White;
            lblFrom.Location = new Point(380, 15);
            lblFrom.AutoSize = true;

            dtpFrom = new DateTimePicker();
            dtpFrom.Format = DateTimePickerFormat.Short;
            dtpFrom.Location = new Point(450, 13);
            dtpFrom.Width = 100;
            dtpFrom.Value = DateTime.Now.AddDays(-30);
            dtpFrom.ValueChanged += FilterChanged;

            Label lblTo = new Label();
            lblTo.Text = "إلى تاريخ:";
            lblTo.ForeColor = Color.White;
            lblTo.Location = new Point(570, 15);
            lblTo.AutoSize = true;

            dtpTo = new DateTimePicker();
            dtpTo.Format = DateTimePickerFormat.Short;
            dtpTo.Location = new Point(640, 13);
            dtpTo.Width = 100;
            dtpTo.Value = DateTime.Now;
            dtpTo.ValueChanged += FilterChanged;

            btnSearch = new Button();
            btnSearch.Text = "🔍 بحث";
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.BackColor = Color.FromArgb(200, 168, 75);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Location = new Point(760, 10);
            btnSearch.Size = new Size(80, 28);
            btnSearch.Click += BtnSearch_Click;

            btnExport = new Button();
            btnExport.Text = "📊 تصدير CSV";
            btnExport.FlatStyle = FlatStyle.Flat;
            btnExport.BackColor = Color.FromArgb(16, 201, 127);
            btnExport.ForeColor = Color.Black;
            btnExport.Location = new Point(850, 10);
            btnExport.Size = new Size(100, 28);
            btnExport.Click += BtnExport_Click;

            lblTotal = new Label();
            lblTotal.Text = "إجمالي السجلات: 0";
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(960, 15);
            lblTotal.AutoSize = true;

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(lblFrom);
            searchPanel.Controls.Add(dtpFrom);
            searchPanel.Controls.Add(lblTo);
            searchPanel.Controls.Add(dtpTo);
            searchPanel.Controls.Add(btnSearch);
            searchPanel.Controls.Add(btnExport);
            searchPanel.Controls.Add(lblTotal);

            // DataGridView
            dgvAudit = new DataGridView();
            dgvAudit.Dock = DockStyle.Fill;
            dgvAudit.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvAudit.ForeColor = Color.White;
            dgvAudit.GridColor = Color.FromArgb(30, 45, 82);
            dgvAudit.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAudit.RightToLeft = RightToLeft.Yes;
            dgvAudit.ReadOnly = true;
            dgvAudit.RowHeadersVisible = false;
            dgvAudit.AllowUserToAddRows = false;

            this.Controls.Add(dgvAudit);
            this.Controls.Add(searchPanel);
        }

        private void LoadAuditLog()
        {
            string keyword = txtSearch.Text.Trim();
            string from = dtpFrom.Value.ToString("yyyy-MM-dd");
            string to = dtpTo.Value.ToString("yyyy-MM-dd");

            string query = @"
                SELECT ID, Action, TableName, RecordID, Description, Username, CreatedAt
                FROM AuditLog
                WHERE CreatedAt >= #" + from + "# AND CreatedAt <= #" + to + "#";
            if (!string.IsNullOrEmpty(keyword))
                query += " AND (Username LIKE '%" + keyword.Replace("'", "''") + "%' OR Description LIKE '%" + keyword.Replace("'", "''") + "%')";
            query += " ORDER BY CreatedAt DESC";

            DataTable dt = DatabaseManager.ExecuteQuery(query);
            dgvAudit.DataSource = dt;
            if (dgvAudit.Columns.Count > 0)
            {
                dgvAudit.Columns["ID"].HeaderText = "م";
                dgvAudit.Columns["Action"].HeaderText = "الإجراء";
                dgvAudit.Columns["TableName"].HeaderText = "الجدول";
                dgvAudit.Columns["RecordID"].HeaderText = "رقم السجل";
                dgvAudit.Columns["Description"].HeaderText = "الوصف";
                dgvAudit.Columns["Username"].HeaderText = "المستخدم";
                dgvAudit.Columns["CreatedAt"].HeaderText = "التاريخ والوقت";
                dgvAudit.AutoResizeColumns();
            }
            lblTotal.Text = $"إجمالي السجلات: {dt.Rows.Count}";
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadAuditLog();
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            LoadAuditLog();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadAuditLog();
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            DataTable dt = dgvAudit.DataSource as DataTable;
            if (dt != null && dt.Rows.Count > 0)
                ExportHelper.ExportToCSV(dt, $"AuditLog_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
            else
                MessageBox.Show("لا توجد بيانات للتصدير.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}