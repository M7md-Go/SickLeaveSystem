using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmEmployeeSelector : Form
    {
        private DataTable employeesData;
        private DataGridView dgvEmployees;
        private TextBox txtSearch;
        private Button btnSearch;
        private Button btnSelect;
        private Button btnCancel;

        public int SelectedEmployeeID { get; private set; }
        public string SelectedEmployeeName { get; private set; }
        public string SelectedEmployeeCode { get; private set; }
        public string SelectedEmployeeJob { get; private set; }
        public string SelectedEmployeeDept { get; private set; }

        public frmEmployeeSelector(DataTable employees)
        {
            employeesData = employees;
            InitializeComponent();
            LoadEmployees();
        }

        private void InitializeComponent()
        {
            this.Text = "اختر موظفاً";
            this.Size = new Size(650, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(13, 24, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            // لوحة البحث
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Height = 50;
            searchPanel.BackColor = Color.FromArgb(8, 15, 30);
            searchPanel.Padding = new Padding(8);

            Label lblSearch = new Label();
            lblSearch.Text = "بحث:";
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(10, 12);
            lblSearch.AutoSize = true;

            txtSearch = new TextBox();
            txtSearch.Location = new Point(60, 10);
            txtSearch.Width = 200;
            txtSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtSearch.ForeColor = Color.White;
            txtSearch.TextChanged += TxtSearch_TextChanged;

            btnSearch = new Button();
            btnSearch.Text = "🔍 بحث";
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.BackColor = Color.FromArgb(200, 168, 75);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Location = new Point(280, 8);
            btnSearch.Size = new Size(80, 28);
            btnSearch.Click += BtnSearch_Click;

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(btnSearch);

            // DataGridView
            dgvEmployees = new DataGridView();
            dgvEmployees.Dock = DockStyle.Fill;
            dgvEmployees.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvEmployees.ForeColor = Color.White;
            dgvEmployees.GridColor = Color.FromArgb(30, 45, 82);
            dgvEmployees.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmployees.MultiSelect = false;
            dgvEmployees.ReadOnly = true;
            dgvEmployees.RowHeadersVisible = false;
            dgvEmployees.AllowUserToAddRows = false;
            dgvEmployees.RightToLeft = RightToLeft.Yes;
            dgvEmployees.CellDoubleClick += DgvEmployees_CellDoubleClick;

            // لوحة الأزرار السفلية
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(8, 15, 30);

            btnSelect = new Button();
            btnSelect.Text = "اختيار";
            btnSelect.FlatStyle = FlatStyle.Flat;
            btnSelect.BackColor = Color.FromArgb(16, 201, 127);
            btnSelect.ForeColor = Color.Black;
            btnSelect.Size = new Size(100, 35);
            btnSelect.Location = new Point(150, 8);
            btnSelect.Click += BtnSelect_Click;

            btnCancel = new Button();
            btnCancel.Text = "إلغاء";
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.BackColor = Color.FromArgb(240, 79, 100);
            btnCancel.ForeColor = Color.White;
            btnCancel.Size = new Size(100, 35);
            btnCancel.Location = new Point(260, 8);
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            buttonPanel.Controls.Add(btnSelect);
            buttonPanel.Controls.Add(btnCancel);

            this.Controls.Add(dgvEmployees);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(searchPanel);
        }

        private void LoadEmployees()
        {
            string filter = txtSearch.Text.Trim().ToLower();
            DataTable filtered = employeesData.Clone();
            foreach (DataRow row in employeesData.Rows)
            {
                string name = row["Name"].ToString().ToLower();
                string code = row["Code"].ToString().ToLower();
                if (string.IsNullOrEmpty(filter) || name.Contains(filter) || code.Contains(filter))
                    filtered.ImportRow(row);
            }
            dgvEmployees.DataSource = filtered;

            if (dgvEmployees.Columns.Count > 0)
            {
                dgvEmployees.Columns["ID"].HeaderText = "م";
                dgvEmployees.Columns["Code"].HeaderText = "الكود";
                dgvEmployees.Columns["Name"].HeaderText = "الاسم";
                dgvEmployees.Columns["JobTitle"].HeaderText = "الوظيفة";
                dgvEmployees.Columns["DepartmentName"].HeaderText = "القسم";
                foreach (DataGridViewColumn col in dgvEmployees.Columns)
                    if (col.Name != "Code" && col.Name != "Name" && col.Name != "JobTitle" && col.Name != "DepartmentName" && col.Name != "ID")
                        col.Visible = false;
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadEmployees();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadEmployees();
        }

        private void DgvEmployees_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                SelectCurrentRow();
        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            SelectCurrentRow();
        }

        private void SelectCurrentRow()
        {
            if (dgvEmployees.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار موظف أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            SelectedEmployeeID = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["ID"].Value);
            SelectedEmployeeName = dgvEmployees.CurrentRow.Cells["Name"].Value.ToString();
            SelectedEmployeeCode = dgvEmployees.CurrentRow.Cells["Code"].Value.ToString();
            SelectedEmployeeJob = dgvEmployees.CurrentRow.Cells["JobTitle"].Value.ToString();
            SelectedEmployeeDept = dgvEmployees.CurrentRow.Cells["DepartmentName"].Value.ToString();
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}