using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmSickLeaveDetail : Form
    {
        private int sickLeaveId = 0;
        private bool readOnly = false;
        private int selectedEmployeeId = 0;
        private DataTable attachmentsTable;

        // عناصر التحكم
        private TextBox txtEmpSearch, txtEmpCode, txtEmpJob, txtEmpDept, txtDiagnosis, txtDecisionNo, txtIssuer, txtDoctor, txtNotes;
        private ComboBox cmbStatus;
        private DateTimePicker dtpFrom, dtpTo;
        private Label lblDays;
        private Button btnSearchEmp, btnAddAttachment, btnViewAttachment, btnDeleteAttachment;
        private DataGridView dgvAttachments;
        private Button btnSave, btnCancel;

        public frmSickLeaveDetail(int id = 0, bool readOnlyMode = false)
        {
            sickLeaveId = id;
            readOnly = readOnlyMode;
            InitializeComponent();
            LoadStatuses();
            if (sickLeaveId > 0)
                LoadSickLeaveData();
            if (readOnly)
                SetReadOnly();
        }

        private void InitializeComponent()
        {
            this.Text = sickLeaveId == 0 ? "إضافة إجازة مرضية" : "تفاصيل الإجازة المرضية";
            this.Size = new Size(900, 700);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(13, 24, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            TableLayoutPanel tlp = new TableLayoutPanel();
            tlp.Dock = DockStyle.Fill;
            tlp.ColumnCount = 2;
            tlp.RowCount = 12;
            tlp.Padding = new Padding(15);
            tlp.BackColor = Color.FromArgb(13, 24, 40);

            // البحث عن موظف
            Label lblEmp = new Label();
            lblEmp.Text = "الموظف:";
            lblEmp.ForeColor = Color.White;
            lblEmp.TextAlign = ContentAlignment.MiddleRight;
            txtEmpSearch = new TextBox();
            txtEmpSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtEmpSearch.ForeColor = Color.White;
            txtEmpSearch.Dock = DockStyle.Fill;
            btnSearchEmp = new Button();
            btnSearchEmp.Text = "🔍";
            btnSearchEmp.FlatStyle = FlatStyle.Flat;
            btnSearchEmp.BackColor = Color.FromArgb(200, 168, 75);
            btnSearchEmp.Size = new Size(40, 25);
            btnSearchEmp.Click += BtnSearchEmp_Click;

            Panel empPanel = new Panel();
            empPanel.Controls.Add(txtEmpSearch);
            empPanel.Controls.Add(btnSearchEmp);
            txtEmpSearch.Dock = DockStyle.Fill;
            btnSearchEmp.Dock = DockStyle.Right;
            tlp.Controls.Add(lblEmp, 0, 0);
            tlp.Controls.Add(empPanel, 1, 0);

            // كود الموظف (للقراءة فقط)
            Label lblCode = new Label();
            lblCode.Text = "كود الموظف:";
            lblCode.ForeColor = Color.White;
            txtEmpCode = new TextBox();
            txtEmpCode.ReadOnly = true;
            txtEmpCode.BackColor = Color.FromArgb(22, 30, 50);
            txtEmpCode.ForeColor = Color.White;
            tlp.Controls.Add(lblCode, 0, 1);
            tlp.Controls.Add(txtEmpCode, 1, 1);

            // الوظيفة
            Label lblJob = new Label();
            lblJob.Text = "الوظيفة:";
            lblJob.ForeColor = Color.White;
            txtEmpJob = new TextBox();
            txtEmpJob.ReadOnly = true;
            txtEmpJob.BackColor = Color.FromArgb(22, 30, 50);
            tlp.Controls.Add(lblJob, 0, 2);
            tlp.Controls.Add(txtEmpJob, 1, 2);

            // القسم
            Label lblDept = new Label();
            lblDept.Text = "القسم:";
            lblDept.ForeColor = Color.White;
            txtEmpDept = new TextBox();
            txtEmpDept.ReadOnly = true;
            txtEmpDept.BackColor = Color.FromArgb(22, 30, 50);
            tlp.Controls.Add(lblDept, 0, 3);
            tlp.Controls.Add(txtEmpDept, 1, 3);

            // تاريخ البداية والنهاية
            Label lblFrom = new Label();
            lblFrom.Text = "تاريخ البداية:";
            lblFrom.ForeColor = Color.White;
            dtpFrom = new DateTimePicker();
            dtpFrom.Format = DateTimePickerFormat.Short;
            dtpFrom.ValueChanged += CalcDays;
            tlp.Controls.Add(lblFrom, 0, 4);
            tlp.Controls.Add(dtpFrom, 1, 4);

            Label lblTo = new Label();
            lblTo.Text = "تاريخ النهاية:";
            lblTo.ForeColor = Color.White;
            dtpTo = new DateTimePicker();
            dtpTo.Format = DateTimePickerFormat.Short;
            dtpTo.ValueChanged += CalcDays;
            tlp.Controls.Add(lblTo, 0, 5);
            tlp.Controls.Add(dtpTo, 1, 5);

            // عدد الأيام (تلقائي)
            Label lblDaysLabel = new Label();
            lblDaysLabel.Text = "عدد الأيام:";
            lblDaysLabel.ForeColor = Color.White;
            lblDays = new Label();
            lblDays.Text = "0";
            lblDays.ForeColor = Color.FromArgb(34, 211, 187);
            lblDays.Font = new Font("Cairo", 10, FontStyle.Bold);
            tlp.Controls.Add(lblDaysLabel, 0, 6);
            tlp.Controls.Add(lblDays, 1, 6);

            // التشخيص
            Label lblDiag = new Label();
            lblDiag.Text = "التشخيص:";
            lblDiag.ForeColor = Color.White;
            txtDiagnosis = new TextBox();
            txtDiagnosis.BackColor = Color.FromArgb(22, 30, 50);
            txtDiagnosis.ForeColor = Color.White;
            tlp.Controls.Add(lblDiag, 0, 7);
            tlp.Controls.Add(txtDiagnosis, 1, 7);

            // القرار 259
            Label lblDec = new Label();
            lblDec.Text = "القرار 259:";
            lblDec.ForeColor = Color.White;
            txtDecisionNo = new TextBox();
            txtDecisionNo.BackColor = Color.FromArgb(22, 30, 50);
            tlp.Controls.Add(lblDec, 0, 8);
            tlp.Controls.Add(txtDecisionNo, 1, 8);

            // جهة الإصدار
            Label lblIssuer = new Label();
            lblIssuer.Text = "جهة الإصدار:";
            lblIssuer.ForeColor = Color.White;
            txtIssuer = new TextBox();
            txtIssuer.BackColor = Color.FromArgb(22, 30, 50);
            tlp.Controls.Add(lblIssuer, 0, 9);
            tlp.Controls.Add(txtIssuer, 1, 9);

            // الطبيب/المستشفى
            Label lblDoctor = new Label();
            lblDoctor.Text = "الطبيب / المستشفى:";
            lblDoctor.ForeColor = Color.White;
            txtDoctor = new TextBox();
            txtDoctor.BackColor = Color.FromArgb(22, 30, 50);
            tlp.Controls.Add(lblDoctor, 0, 10);
            tlp.Controls.Add(txtDoctor, 1, 10);

            // الحالة
            Label lblStatus = new Label();
            lblStatus.Text = "الحالة:";
            lblStatus.ForeColor = Color.White;
            cmbStatus = new ComboBox();
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.BackColor = Color.FromArgb(22, 30, 50);
            cmbStatus.ForeColor = Color.White;
            tlp.Controls.Add(lblStatus, 0, 11);
            tlp.Controls.Add(cmbStatus, 1, 11);

            this.Controls.Add(tlp);

            // لوحة المرفقات
            GroupBox gbAttachments = new GroupBox();
            gbAttachments.Text = "المستندات الطبية";
            gbAttachments.ForeColor = Color.White;
            gbAttachments.Dock = DockStyle.Bottom;
            gbAttachments.Height = 200;
            gbAttachments.BackColor = Color.FromArgb(8, 15, 30);

            dgvAttachments = new DataGridView();
            dgvAttachments.Dock = DockStyle.Fill;
            dgvAttachments.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvAttachments.ForeColor = Color.White;
            dgvAttachments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAttachments.RightToLeft = RightToLeft.Yes;
            dgvAttachments.ReadOnly = true;
            dgvAttachments.AllowUserToAddRows = false;
            dgvAttachments.RowHeadersVisible = false;
            dgvAttachments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAttachments.CellDoubleClick += DgvAttachments_CellDoubleClick;

            Panel attachmentButtons = new Panel();
            attachmentButtons.Dock = DockStyle.Bottom;
            attachmentButtons.Height = 40;
            btnAddAttachment = new Button();
            btnAddAttachment.Text = "📎 إضافة ملف";
            btnAddAttachment.FlatStyle = FlatStyle.Flat;
            btnAddAttachment.BackColor = Color.FromArgb(79, 142, 247);
            btnAddAttachment.Size = new Size(100, 30);
            btnAddAttachment.Location = new Point(8, 5);
            btnAddAttachment.Click += BtnAddAttachment_Click;

            btnViewAttachment = new Button();
            btnViewAttachment.Text = "👁 فتح";
            btnViewAttachment.FlatStyle = FlatStyle.Flat;
            btnViewAttachment.BackColor = Color.FromArgb(34, 211, 187);
            btnViewAttachment.Size = new Size(80, 30);
            btnViewAttachment.Location = new Point(118, 5);
            btnViewAttachment.Click += BtnViewAttachment_Click;

            btnDeleteAttachment = new Button();
            btnDeleteAttachment.Text = "🗑 حذف";
            btnDeleteAttachment.FlatStyle = FlatStyle.Flat;
            btnDeleteAttachment.BackColor = Color.FromArgb(240, 79, 100);
            btnDeleteAttachment.Size = new Size(80, 30);
            btnDeleteAttachment.Location = new Point(208, 5);
            btnDeleteAttachment.Click += BtnDeleteAttachment_Click;

            attachmentButtons.Controls.Add(btnAddAttachment);
            attachmentButtons.Controls.Add(btnViewAttachment);
            attachmentButtons.Controls.Add(btnDeleteAttachment);

            gbAttachments.Controls.Add(dgvAttachments);
            gbAttachments.Controls.Add(attachmentButtons);
            this.Controls.Add(gbAttachments);

            // لوحة الأزرار الرئيسية
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(8, 15, 30);

            btnSave = new Button();
            btnSave.Text = "💾 حفظ";
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.BackColor = Color.FromArgb(16, 201, 127);
            btnSave.ForeColor = Color.Black;
            btnSave.Size = new Size(100, 35);
            btnSave.Location = new Point(150, 8);
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button();
            btnCancel.Text = "إلغاء";
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.BackColor = Color.FromArgb(240, 79, 100);
            btnCancel.ForeColor = Color.White;
            btnCancel.Size = new Size(100, 35);
            btnCancel.Location = new Point(260, 8);
            btnCancel.Click += (s, e) => this.Close();

            buttonPanel.Controls.Add(btnSave);
            buttonPanel.Controls.Add(btnCancel);
            this.Controls.Add(buttonPanel);
        }

        private void LoadStatuses()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Value");
            dt.Columns.Add("Text");
            dt.Rows.Add(Constants.SickLeaveStatusReview, "تحت المراجعة");
            dt.Rows.Add(Constants.SickLeaveStatusApproved, "معتمدة");
            dt.Rows.Add(Constants.SickLeaveStatusRejected, "مرفوضة");
            dt.Rows.Add(Constants.SickLeaveStatusExpired, "منتهية");
            cmbStatus.DataSource = dt;
            cmbStatus.DisplayMember = "Text";
            cmbStatus.ValueMember = "Value";
        }

        private void BtnSearchEmp_Click(object sender, EventArgs e)
        {
            string keyword = txtEmpSearch.Text.Trim();
            if (string.IsNullOrEmpty(keyword))
            {
                MessageBox.Show("أدخل اسم الموظف أو الكود للبحث.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            DataTable dt = DatabaseManager.ExecuteQuery(
                "SELECT ID, Code, Name, JobTitle, DepartmentName FROM Employees WHERE (Name LIKE '%" + keyword.Replace("'", "''") + "%' OR Code LIKE '%" + keyword.Replace("'", "''") + "%') AND Status <> 'inactive'");
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("لم يتم العثور على موظف.", "بحث", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            // عرض قائمة بسيطة أو فتح نافذة اختيار
            frmEmployeeSelector selector = new frmEmployeeSelector(dt);
            if (selector.ShowDialog() == DialogResult.OK)
            {
                selectedEmployeeId = selector.SelectedEmployeeID;
                txtEmpSearch.Text = selector.SelectedEmployeeName;
                txtEmpCode.Text = selector.SelectedEmployeeCode;
                txtEmpJob.Text = selector.SelectedEmployeeJob;
                txtEmpDept.Text = selector.SelectedEmployeeDept;
            }
        }

        private void CalcDays(object sender, EventArgs e)
        {
            int days = ValidationHelper.CalculateDays(dtpFrom.Value, dtpTo.Value);
            lblDays.Text = days.ToString();
        }

        private void LoadSickLeaveData()
        {
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM SickLeaves WHERE ID=?", DatabaseManager.CreateParameter("@id", sickLeaveId));
            if (dt.Rows.Count > 0)
            {
                DataRow r = dt.Rows[0];
                selectedEmployeeId = Convert.ToInt32(r["EmployeeID"]);
                txtEmpSearch.Text = r["EmpName"].ToString();
                txtEmpCode.Text = r["EmpCode"].ToString();
                txtEmpJob.Text = r["EmpJob"].ToString();
                txtEmpDept.Text = r["DepartmentName"].ToString();
                dtpFrom.Value = Convert.ToDateTime(r["DateFrom"]);
                dtpTo.Value = Convert.ToDateTime(r["DateTo"]);
                txtDiagnosis.Text = r["Diagnosis"].ToString();
                txtDecisionNo.Text = r["DecisionNo"].ToString();
                txtIssuer.Text = r["Issuer"].ToString();
                txtDoctor.Text = r["Doctor"].ToString();
                cmbStatus.SelectedValue = r["Status"].ToString();
                txtNotes.Text = r["Notes"].ToString();
                CalcDays(null, null);
                LoadAttachments();
            }
        }

        private void LoadAttachments()
        {
            attachmentsTable = DatabaseManager.ExecuteQuery("SELECT ID, FileName, FileSize, CreatedAt FROM Attachments WHERE SickLeaveID=?", DatabaseManager.CreateParameter("@slId", sickLeaveId));
            dgvAttachments.DataSource = attachmentsTable;
            if (dgvAttachments.Columns.Count > 0)
            {
                dgvAttachments.Columns["ID"].Visible = false;
                dgvAttachments.Columns["FileName"].HeaderText = "اسم الملف";
                dgvAttachments.Columns["FileSize"].HeaderText = "الحجم";
                dgvAttachments.Columns["CreatedAt"].HeaderText = "تاريخ الرفع";
            }
            btnDeleteAttachment.Enabled = !readOnly && attachmentsTable.Rows.Count > 0;
            btnAddAttachment.Enabled = !readOnly;
        }

        private void BtnAddAttachment_Click(object sender, EventArgs e)
        {
            if (sickLeaveId == 0)
            {
                MessageBox.Show("يرجى حفظ الإجازة أولاً قبل إضافة المرفقات.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Multiselect = true;
                ofd.Filter = "All files|*.*|PDF files|*.pdf|Image files|*.jpg;*.png;*.bmp|Office files|*.doc;*.docx;*.xls;*.xlsx";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    foreach (string file in ofd.FileNames)
                    {
                        string destPath = FileHelper.CopyAttachmentFile(file, sickLeaveId);
                        FileInfo fi = new FileInfo(file);
                        DatabaseManager.ExecuteNonQuery(
                            "INSERT INTO Attachments (SickLeaveID, FileName, FilePath, FileSize, FileType, CreatedAt) VALUES (?, ?, ?, ?, ?, NOW())",
                            DatabaseManager.CreateParameter("@slId", sickLeaveId),
                            DatabaseManager.CreateParameter("@fname", Path.GetFileName(file)),
                            DatabaseManager.CreateParameter("@fpath", destPath),
                            DatabaseManager.CreateParameter("@fsize", fi.Length),
                            DatabaseManager.CreateParameter("@ftype", fi.Extension.ToLower()));
                    }
                    LoadAttachments();
                    AuditHelper.Log("إضافة مرفقات", Constants.TableAttachments, sickLeaveId, $"تم إضافة {ofd.FileNames.Length} ملف(ملفات) للإجازة رقم {sickLeaveId}");
                }
            }
        }

        private void BtnViewAttachment_Click(object sender, EventArgs e)
        {
            if (dgvAttachments.CurrentRow == null) return;
            int attachId = Convert.ToInt32(dgvAttachments.CurrentRow.Cells["ID"].Value);
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT FilePath FROM Attachments WHERE ID=?", DatabaseManager.CreateParameter("@id", attachId));
            if (dt.Rows.Count > 0)
            {
                string path = dt.Rows[0]["FilePath"].ToString();
                FileHelper.OpenFile(path);
            }
        }

        private void BtnDeleteAttachment_Click(object sender, EventArgs e)
        {
            if (readOnly) return;
            if (dgvAttachments.CurrentRow == null) return;
            int attachId = Convert.ToInt32(dgvAttachments.CurrentRow.Cells["ID"].Value);
            if (MessageBox.Show("هل أنت متأكد من حذف هذا المرفق؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                DataTable dt = DatabaseManager.ExecuteQuery("SELECT FilePath FROM Attachments WHERE ID=?", DatabaseManager.CreateParameter("@id", attachId));
                if (dt.Rows.Count > 0)
                {
                    string path = dt.Rows[0]["FilePath"].ToString();
                    FileHelper.DeleteAttachmentFile(path);
                }
                DatabaseManager.ExecuteNonQuery("DELETE FROM Attachments WHERE ID=?", DatabaseManager.CreateParameter("@id", attachId));
                LoadAttachments();
                AuditHelper.Log("حذف مرفق", Constants.TableAttachments, sickLeaveId, $"تم حذف مرفق من الإجازة {sickLeaveId}");
            }
        }

        private void DgvAttachments_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            BtnViewAttachment_Click(sender, null);
        }

        private void SetReadOnly()
        {
            readOnly = true;
            txtEmpSearch.ReadOnly = true;
            btnSearchEmp.Enabled = false;
            dtpFrom.Enabled = false;
            dtpTo.Enabled = false;
            txtDiagnosis.ReadOnly = true;
            txtDecisionNo.ReadOnly = true;
            txtIssuer.ReadOnly = true;
            txtDoctor.ReadOnly = true;
            cmbStatus.Enabled = false;
            txtNotes.ReadOnly = true;
            btnAddAttachment.Visible = false;
            btnDeleteAttachment.Visible = false;
            btnSave.Visible = false;
            this.Text = "عرض الإجازة المرضية";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بالتعديل.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (selectedEmployeeId == 0)
            {
                MessageBox.Show("الرجاء اختيار موظف.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dtpFrom.Value > dtpTo.Value)
            {
                MessageBox.Show("تاريخ النهاية يجب أن يكون بعد تاريخ البداية.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SickLeaveModel sl = new SickLeaveModel();
            sl.EmployeeID = selectedEmployeeId;
            sl.EmpCode = txtEmpCode.Text;
            sl.EmpName = txtEmpSearch.Text;
            sl.EmpJob = txtEmpJob.Text;
            sl.DepartmentName = txtEmpDept.Text;
            sl.DateFrom = dtpFrom.Value;
            sl.DateTo = dtpTo.Value;
            sl.Diagnosis = txtDiagnosis.Text;
            sl.DecisionNo = txtDecisionNo.Text;
            sl.Issuer = txtIssuer.Text;
            sl.Doctor = txtDoctor.Text;
            sl.Status = cmbStatus.SelectedValue.ToString();
            sl.Notes = txtNotes.Text;
            sl.AddedBy = GlobalState.CurrentUser.Username;

            if (sickLeaveId == 0)
            {
                int newId = BusinessLogic.AddSickLeave(sl);
                if (newId > 0)
                {
                    sickLeaveId = newId;
                    AuditHelper.Log(Constants.AuditActionInsert, Constants.TableSickLeaves, newId, $"إضافة إجازة للموظف {sl.EmpName}");
                    MessageBox.Show("تمت إضافة الإجازة بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشلت إضافة الإجازة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                sl.ID = sickLeaveId;
                bool success = BusinessLogic.UpdateSickLeave(sl);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionUpdate, Constants.TableSickLeaves, sickLeaveId, $"تعديل إجازة للموظف {sl.EmpName}");
                    MessageBox.Show("تم تعديل الإجازة بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشل تعديل الإجازة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}