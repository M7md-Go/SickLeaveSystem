using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class DashboardControl : UserControl
    {
        private Label lblEmpCount, lblTotalSL, lblActiveSL, lblApproved, lblRejected, lblReview, lblTotalDays, lblMonthSL;
        private DataGridView dgvRecentSL;

        public DashboardControl()
        {
            InitializeComponent();
            LoadStats();
            LoadRecentSickLeaves();
        }

        private void InitializeComponent()
        {
            this.AutoScroll = true;
            this.BackColor = Color.FromArgb(7, 11, 24);
            int y = 20;
            // إحصائيات
            Label title = new Label();
            title.Text = "لوحة التحكم";
            title.Font = new Font("Cairo", 16, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(200, 168, 75);
            title.Location = new Point(20, y);
            title.AutoSize = true;
            this.Controls.Add(title);
            y += 40;

            // إنشاء 8 بطاقات إحصائيات
            var stats = new (string icon, string label, Color color)[]
            {
                ("👥", "إجمالي الموظفين", Color.FromArgb(79, 142, 247)),
                ("📋", "إجمالي الإجازات", Color.FromArgb(200, 168, 75)),
                ("✅", "إجازات نشطة", Color.FromArgb(34, 211, 187)),
                ("✔", "معتمدة", Color.FromArgb(16, 201, 127)),
                ("✗", "مرفوضة", Color.FromArgb(240, 79, 100)),
                ("⏳", "تحت المراجعة", Color.FromArgb(245, 158, 11)),
                ("📅", "إجمالي الأيام", Color.FromArgb(167, 139, 250)),
                ("📆", "هذا الشهر", Color.FromArgb(200, 168, 75))
            };
            int x = 20;
            int cardWidth = 140;
            int cardHeight = 80;
            for (int i = 0; i < stats.Length; i++)
            {
                Panel card = new Panel();
                card.BackColor = Color.FromArgb(16, 24, 40);
                card.Size = new Size(cardWidth, cardHeight);
                card.Location = new Point(x, y);
                card.BorderStyle = BorderStyle.FixedSingle;
                Label icon = new Label();
                icon.Text = stats[i].icon;
                icon.Font = new Font("Segoe UI", 20);
                icon.Location = new Point(10, 15);
                icon.AutoSize = false;
                icon.Size = new Size(40, 40);
                Label val = new Label();
                val.Name = $"val{i}";
                val.Font = new Font("Cairo", 14, FontStyle.Bold);
                val.ForeColor = stats[i].color;
                val.Location = new Point(60, 15);
                val.AutoSize = true;
                Label lbl = new Label();
                lbl.Text = stats[i].label;
                lbl.Font = new Font("Cairo", 9);
                lbl.ForeColor = Color.Gray;
                lbl.Location = new Point(60, 45);
                lbl.AutoSize = true;
                card.Controls.Add(icon);
                card.Controls.Add(val);
                card.Controls.Add(lbl);
                this.Controls.Add(card);
                x += cardWidth + 10;
                if ((i + 1) % 4 == 0) { x = 20; y += cardHeight + 10; }
            }
            // حفظ المراجع للقيم
            lblEmpCount = (Label)this.Controls.Find("val0", true)[0];
            lblTotalSL = (Label)this.Controls.Find("val1", true)[0];
            lblActiveSL = (Label)this.Controls.Find("val2", true)[0];
            lblApproved = (Label)this.Controls.Find("val3", true)[0];
            lblRejected = (Label)this.Controls.Find("val4", true)[0];
            lblReview = (Label)this.Controls.Find("val5", true)[0];
            lblTotalDays = (Label)this.Controls.Find("val6", true)[0];
            lblMonthSL = (Label)this.Controls.Find("val7", true)[0];

            y += cardHeight + 20;
            // أحدث الإجازات
            Label recentTitle = new Label();
            recentTitle.Text = "آخر الإجازات المُضافة";
            recentTitle.Font = new Font("Cairo", 12, FontStyle.Bold);
            recentTitle.ForeColor = Color.White;
            recentTitle.Location = new Point(20, y);
            recentTitle.AutoSize = true;
            this.Controls.Add(recentTitle);
            y += 30;
            dgvRecentSL = new DataGridView();
            dgvRecentSL.Size = new Size(this.Width - 40, 300);
            dgvRecentSL.Location = new Point(20, y);
            dgvRecentSL.BackgroundColor = Color.FromArgb(16, 24, 40);
            dgvRecentSL.ForeColor = Color.White;
            dgvRecentSL.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvRecentSL.RightToLeft = RightToLeft.Yes;
            this.Controls.Add(dgvRecentSL);
        }

        private void LoadStats()
        {
            int empCount = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM Employees"));
            int totalSL = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves"));
            int activeSL = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves WHERE DateFrom <= DATE() AND DateTo >= DATE()"));
            int approved = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves WHERE Status='approved'"));
            int rejected = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves WHERE Status='rejected'"));
            int review = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves WHERE Status='review'"));
            int totalDays = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT SUM(Days) FROM SickLeaves"));
            int thisMonth = Convert.ToInt32(DatabaseManager.ExecuteScalar("SELECT COUNT(*) FROM SickLeaves WHERE YEAR(DateFrom)=YEAR(DATE()) AND MONTH(DateFrom)=MONTH(DATE())"));

            lblEmpCount.Text = empCount.ToString();
            lblTotalSL.Text = totalSL.ToString();
            lblActiveSL.Text = activeSL.ToString();
            lblApproved.Text = approved.ToString();
            lblRejected.Text = rejected.ToString();
            lblReview.Text = review.ToString();
            lblTotalDays.Text = totalDays.ToString();
            lblMonthSL.Text = thisMonth.ToString();
        }

        private void LoadRecentSickLeaves()
        {
            DataTable dt = DatabaseManager.ExecuteQuery(
                "SELECT TOP 10 EmpName, DepartmentName, DateFrom, DateTo, Days, Status FROM SickLeaves ORDER BY ID DESC");
            dgvRecentSL.DataSource = dt;
            dgvRecentSL.Columns["EmpName"].HeaderText = "الموظف";
            dgvRecentSL.Columns["DepartmentName"].HeaderText = "القسم";
            dgvRecentSL.Columns["DateFrom"].HeaderText = "من";
            dgvRecentSL.Columns["DateTo"].HeaderText = "إلى";
            dgvRecentSL.Columns["Days"].HeaderText = "الأيام";
            dgvRecentSL.Columns["Status"].HeaderText = "الحالة";
        }
    }
}