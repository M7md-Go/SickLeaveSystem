using System;
using System.Data;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Text = "تسجيل الدخول";
            SetupRTL();
            LoadTheme();
        }

        private void SetupRTL()
        {
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            lblUsername.Text = "اسم المستخدم:";
            lblPassword.Text = "كلمة المرور:";
            btnLogin.Text = "دخول";
            btnCancel.Text = "إلغاء";
            chkShowPassword.Text = "عرض كلمة المرور";
        }

        private void LoadTheme()
        {
            this.BackColor = System.Drawing.Color.FromArgb(11, 16, 34);
            lblTitle.ForeColor = System.Drawing.Color.FromArgb(200, 168, 75);
            lblSub.ForeColor = System.Drawing.Color.FromArgb(155, 168, 208);
            txtUsername.BackColor = System.Drawing.Color.FromArgb(22, 30, 50);
            txtUsername.ForeColor = System.Drawing.Color.White;
            txtPassword.BackColor = System.Drawing.Color.FromArgb(22, 30, 50);
            txtPassword.ForeColor = System.Drawing.Color.White;
            btnLogin.BackColor = System.Drawing.Color.FromArgb(200, 168, 75);
            btnLogin.ForeColor = System.Drawing.Color.Black;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("يرجى إدخال اسم المستخدم وكلمة المرور.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UserModel user = BusinessLogic.GetUserByUsername(username);
            if (user == null || !user.IsActive)
            {
                AuditHelper.LogLogin(username, false);
                MessageBox.Show("اسم المستخدم غير صحيح أو الحساب غير نشط.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            bool valid = SecurityHelper.VerifyPassword(password, user.PasswordHash, user.PasswordSalt);
            if (!valid)
            {
                AuditHelper.LogLogin(username, false);
                MessageBox.Show("كلمة المرور غير صحيحة.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // تسجيل الدخول ناجح
            GlobalState.CurrentUser = user;
            BusinessLogic.UpdateLastLogin(user.ID);
            AuditHelper.LogLogin(username, true);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
        }
    }
}