using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmEmployees : Form
    {
        private DataTable employeesTable;
        private BindingSource bindingSource;
        private TextBox txtSearch;
        private ComboBox cmbDepartment;
        private ComboBox cmbStatus;
        private Button btnSearch;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnRefresh;
        private Button btnExport;
        private DataGridView dgvEmployees;
        private Label lblTotal;

        public frmEmployees()
        {
            InitializeComponent();
            LoadDepartments();
            LoadStatuses();
            LoadEmployees();
            ApplyPermissions();
        }

        private void InitializeComponent()
        {
            this.Text = "إدارة الموظفين";
            this.Size = new Size(1100, 600);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // لوحة البحث
            Panel searchPanel = new Panel();
            searchPanel.Dock = DockStyle.Top;
            searchPanel.Height = 60;
            searchPanel.BackColor = Color.FromArgb(13, 24, 40);
            searchPanel.Padding = new Padding(10);

            Label lblSearch = new Label();
            lblSearch.Text = "بحث:";
            lblSearch.ForeColor = Color.White;
            lblSearch.Location = new Point(10, 20);
            lblSearch.AutoSize = true;
            txtSearch = new TextBox();
            txtSearch.Location = new Point(60, 18);
            txtSearch.Width = 200;
            txtSearch.BackColor = Color.FromArgb(22, 30, 50);
            txtSearch.ForeColor = Color.White;
            txtSearch.TextChanged += TxtSearch_TextChanged;

            Label lblDept = new Label();
            lblDept.Text = "القسم:";
            lblDept.ForeColor = Color.White;
            lblDept.Location = new Point(280, 20);
            lblDept.AutoSize = true;
            cmbDepartment = new ComboBox();
            cmbDepartment.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDepartment.Location = new Point(330, 18);
            cmbDepartment.Width = 150;
            cmbDepartment.BackColor = Color.FromArgb(22, 30, 50);
            cmbDepartment.ForeColor = Color.White;
            cmbDepartment.SelectedIndexChanged += CmbFilter_Changed;

            Label lblStatus = new Label();
            lblStatus.Text = "الحالة:";
            lblStatus.ForeColor = Color.White;
            lblStatus.Location = new Point(500, 20);
            lblStatus.AutoSize = true;
            cmbStatus = new ComboBox();
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbStatus.Location = new Point(550, 18);
            cmbStatus.Width = 120;
            cmbStatus.BackColor = Color.FromArgb(22, 30, 50);
            cmbStatus.ForeColor = Color.White;
            cmbStatus.SelectedIndexChanged += CmbFilter_Changed;

            btnSearch = new Button();
            btnSearch.Text = "🔍 بحث";
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.BackColor = Color.FromArgb(200, 168, 75);
            btnSearch.ForeColor = Color.Black;
            btnSearch.Location = new Point(690, 16);
            btnSearch.Size = new Size(80, 28);
            btnSearch.Click += BtnSearch_Click;

            btnRefresh = new Button();
            btnRefresh.Text = "🔄 تحديث";
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.BackColor = Color.FromArgb(79, 142, 247);
            btnRefresh.ForeColor = Color.White;
            btnRefresh.Location = new Point(780, 16);
            btnRefresh.Size = new Size(80, 28);
            btnRefresh.Click += BtnRefresh_Click;

            searchPanel.Controls.Add(lblSearch);
            searchPanel.Controls.Add(txtSearch);
            searchPanel.Controls.Add(lblDept);
            searchPanel.Controls.Add(cmbDepartment);
            searchPanel.Controls.Add(lblStatus);
            searchPanel.Controls.Add(cmbStatus);
            searchPanel.Controls.Add(btnSearch);
            searchPanel.Controls.Add(btnRefresh);

            // شريط الأزرار السفلية
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(13, 24, 40);

            btnAdd = new Button();
            btnAdd.Text = "➕ إضافة موظف";
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.BackColor = Color.FromArgb(16, 201, 127);
            btnAdd.ForeColor = Color.Black;
            btnAdd.Location = new Point(10, 10);
            btnAdd.Size = new Size(120, 30);
            btnAdd.Click += BtnAdd_Click;

            btnEdit = new Button();
            btnEdit.Text = "✏️ تعديل";
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.BackColor = Color.FromArgb(79, 142, 247);
            btnEdit.ForeColor = Color.White;
            btnEdit.Location = new Point(140, 10);
            btnEdit.Size = new Size(100, 30);
            btnEdit.Click += BtnEdit_Click;

            btnDelete = new Button();
            btnDelete.Text = "🗑 حذف";
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.BackColor = Color.FromArgb(240, 79, 100);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(250, 10);
            btnDelete.Size = new Size(100, 30);
            btnDelete.Click += BtnDelete_Click;

            btnExport = new Button();
            btnExport.Text = "📊 تصدير Excel";
            btnExport.FlatStyle = FlatStyle.Flat;
            btnExport.BackColor = Color.FromArgb(167, 139, 250);
            btnExport.ForeColor = Color.White;
            btnExport.Location = new Point(360, 10);
            btnExport.Size = new Size(120, 30);
            btnExport.Click += BtnExport_Click;

            lblTotal = new Label();
            lblTotal.Text = "إجمالي الموظفين: 0";
            lblTotal.ForeColor = Color.White;
            lblTotal.Location = new Point(700, 15);
            lblTotal.AutoSize = true;

            buttonPanel.Controls.Add(btnAdd);
            buttonPanel.Controls.Add(btnEdit);
            buttonPanel.Controls.Add(btnDelete);
            buttonPanel.Controls.Add(btnExport);
            buttonPanel.Controls.Add(lblTotal);

            // DataGridView
            dgvEmployees = new DataGridView();
            dgvEmployees.Dock = DockStyle.Fill;
            dgvEmployees.BackgroundColor = Color.FromArgb(7, 11, 24);
            dgvEmployees.ForeColor = Color.White;
            dgvEmployees.GridColor = Color.FromArgb(30, 45, 82);
            dgvEmployees.BorderStyle = BorderStyle.None;
            dgvEmployees.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvEmployees.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvEmployees.MultiSelect = false;
            dgvEmployees.ReadOnly = true;
            dgvEmployees.RowHeadersVisible = false;
            dgvEmployees.AllowUserToAddRows = false;
            dgvEmployees.RightToLeft = RightToLeft.Yes;
            dgvEmployees.CellDoubleClick += DgvEmployees_CellDoubleClick;

            // إضافة عناصر التحكم للنموذج
            this.Controls.Add(dgvEmployees);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(searchPanel);
        }

        private void LoadDepartments()
        {
            DataTable dt = BusinessLogic.GetAllDepartments();
            cmbDepartment.DataSource = dt;
            cmbDepartment.DisplayMember = "Name";
            cmbDepartment.ValueMember = "ID";
            cmbDepartment.SelectedIndex = -1;
            // إضافة خيار "الكل"
            DataRow row = dt.NewRow();
            row["ID"] = 0;
            row["Name"] = "الكل";
            dt.Rows.InsertAt(row, 0);
            cmbDepartment.SelectedValue = 0;
        }

        private void LoadStatuses()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Value");
            dt.Columns.Add("Text");
            dt.Rows.Add("", "الكل");
            dt.Rows.Add(Constants.EmployeeStatusActive, "نشط");
            dt.Rows.Add(Constants.EmployeeStatusInactive, "غير نشط");
            dt.Rows.Add(Constants.EmployeeStatusOnLeave, "في إجازة");
            cmbStatus.DataSource = dt;
            cmbStatus.DisplayMember = "Text";
            cmbStatus.ValueMember = "Value";
            cmbStatus.SelectedIndex = 0;
        }

        private void LoadEmployees()
        {
            string keyword = txtSearch.Text.Trim();
            int? deptId = null;
            if (cmbDepartment.SelectedValue != null && Convert.ToInt32(cmbDepartment.SelectedValue) > 0)
                deptId = Convert.ToInt32(cmbDepartment.SelectedValue);
            string status = cmbStatus.SelectedValue?.ToString() == "" ? null : cmbStatus.SelectedValue?.ToString();

            employeesTable = BusinessLogic.SearchEmployees(keyword, deptId, status);
            bindingSource = new BindingSource();
            bindingSource.DataSource = employeesTable;
            dgvEmployees.DataSource = bindingSource;

            // تخصيص الأعمدة
            if (dgvEmployees.Columns.Count > 0)
            {
                dgvEmployees.Columns["ID"].HeaderText = "م";
                dgvEmployees.Columns["Code"].HeaderText = "الكود";
                dgvEmployees.Columns["Name"].HeaderText = "الاسم";
                dgvEmployees.Columns["JobTitle"].HeaderText = "الوظيفة";
                dgvEmployees.Columns["DepartmentName"].HeaderText = "القسم";
                dgvEmployees.Columns["HireDate"].HeaderText = "تاريخ التعيين";
                dgvEmployees.Columns["Status"].HeaderText = "الحالة";
                dgvEmployees.Columns["Phone"].HeaderText = "الهاتف";
                // إخفاء الأعمدة غير المرغوب فيها
                string[] hidden = { "DepartmentID", "StartDate", "BirthDate", "NationalID", "Email", "Address", "Notes", "CreatedAt", "UpdatedAt" };
                foreach (string col in hidden)
                    if (dgvEmployees.Columns.Contains(col))
                        dgvEmployees.Columns[col].Visible = false;
            }
            lblTotal.Text = $"إجمالي الموظفين: {employeesTable.Rows.Count}";
        }

        private void ApplyPermissions()
        {
            bool canEdit = SecurityHelper.CanEdit();
            btnAdd.Enabled = canEdit;
            btnEdit.Enabled = canEdit;
            btnDelete.Enabled = SecurityHelper.CanDelete();
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadEmployees();
        }

        private void CmbFilter_Changed(object sender, EventArgs e)
        {
            LoadEmployees();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            LoadEmployees();
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbDepartment.SelectedValue = 0;
            cmbStatus.SelectedIndex = 0;
            LoadEmployees();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بإضافة موظفين.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            frmEmployeeDetail detail = new frmEmployeeDetail();
            if (detail.ShowDialog() == DialogResult.OK)
                LoadEmployees();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بتعديل الموظفين.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dgvEmployees.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار موظف أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["ID"].Value);
            frmEmployeeDetail detail = new frmEmployeeDetail(id);
            if (detail.ShowDialog() == DialogResult.OK)
                LoadEmployees();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanDelete())
            {
                MessageBox.Show("غير مصرح لك بحذف الموظفين.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dgvEmployees.CurrentRow == null)
            {
                MessageBox.Show("الرجاء اختيار موظف أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = Convert.ToInt32(dgvEmployees.CurrentRow.Cells["ID"].Value);
            string name = dgvEmployees.CurrentRow.Cells["Name"].Value.ToString();
            if (MessageBox.Show($"هل أنت متأكد من حذف الموظف '{name}'؟ سيتم نقله إلى سلة المهملات.", "تأكيد الحذف",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                bool success = BusinessLogic.DeleteEmployee(id, GlobalState.CurrentUser.Username);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionDelete, Constants.TableEmployees, id, $"حذف الموظف: {name}");
                    LoadEmployees();
                    MessageBox.Show("تم حذف الموظف ونقله إلى سلة المهملات.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("فشل حذف الموظف.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            ExportHelper.ExportDataGridViewToCSV(dgvEmployees, "Employees_Report.csv");
        }

        private void DgvEmployees_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int id = Convert.ToInt32(dgvEmployees.Rows[e.RowIndex].Cells["ID"].Value);
                frmEmployeeDetail detail = new frmEmployeeDetail(id, true); // وضع العرض فقط
                detail.ShowDialog();
            }
        }
    }
}