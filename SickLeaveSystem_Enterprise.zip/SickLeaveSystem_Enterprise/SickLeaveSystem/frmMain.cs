using System;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmMain : Form
    {
        private Panel sidebar;
        private Panel header;
        private Panel contentPanel;
        private Label lblTitle;
        private Button btnDashboard;
        private Button btnEmployees;
        private Button btnSickLeaves;
        private Button btnReports;
        private Button btnTrash;
        private Button btnAudit;
        private Button btnUsers;
        private Button btnDepartments;
        private Button btnSettings;
        private Button btnBackup;
        private Button btnLogout;
        private Label lblUser;
        private Panel currentPage = null;

        public frmMain()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.Text = GlobalState.AppTitle;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            CreateSidebar();
            CreateHeader();
            CreateContentPanel();
            LoadDashboard();
            CheckPermissions();
        }

        private void CreateSidebar()
        {
            sidebar = new Panel();
            sidebar.Dock = DockStyle.Right;
            sidebar.Width = 220;
            sidebar.BackColor = Color.FromArgb(8, 15, 30);
            sidebar.Padding = new Padding(5);

            // قائمة الأزرار
            btnDashboard = CreateNavButton("📊 لوحة التحكم", 0);
            btnEmployees = CreateNavButton("👥 الموظفين", 1);
            btnSickLeaves = CreateNavButton("🏥 الإجازات المرضية", 2);
            btnReports = CreateNavButton("📈 التقارير", 3);
            btnTrash = CreateNavButton("🗑 سلة المهملات", 4);
            btnAudit = CreateNavButton("📝 سجل التدقيق", 5);
            btnUsers = CreateNavButton("👤 المستخدمين", 6);
            btnDepartments = CreateNavButton("🏢 الأقسام", 7);
            btnSettings = CreateNavButton("⚙️ الإعدادات", 8);
            btnBackup = CreateNavButton("💾 نسخ احتياطي", 9);
            btnLogout = CreateNavButton("🚪 تسجيل خروج", 10);

            sidebar.Controls.Add(btnDashboard);
            sidebar.Controls.Add(btnEmployees);
            sidebar.Controls.Add(btnSickLeaves);
            sidebar.Controls.Add(btnReports);
            sidebar.Controls.Add(btnTrash);
            sidebar.Controls.Add(btnAudit);
            sidebar.Controls.Add(btnUsers);
            sidebar.Controls.Add(btnDepartments);
            sidebar.Controls.Add(btnSettings);
            sidebar.Controls.Add(btnBackup);
            sidebar.Controls.Add(btnLogout);

            this.Controls.Add(sidebar);
        }

        private Button CreateNavButton(string text, int index)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            btn.TextAlign = ContentAlignment.MiddleRight;
            btn.Padding = new Padding(10, 8, 10, 8);
            btn.Dock = DockStyle.Top;
            btn.Height = 45;
            btn.Font = new Font("Cairo", 10);
            btn.ForeColor = Color.WhiteSmoke;
            btn.BackColor = Color.Transparent;
            btn.Tag = index;
            btn.Click += NavButton_Click;
            return btn;
        }

        private void CreateHeader()
        {
            header = new Panel();
            header.Dock = DockStyle.Top;
            header.Height = 60;
            header.BackColor = Color.FromArgb(13, 24, 40);
            lblTitle = new Label();
            lblTitle.Text = "نظام إدارة الإجازات المرضية - Enterprise";
            lblTitle.Font = new Font("Cairo", 14, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(200, 168, 75);
            lblTitle.Dock = DockStyle.Fill;
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            lblUser = new Label();
            lblUser.Text = GlobalState.CurrentUser?.Username;
            lblUser.Font = new Font("Cairo", 9);
            lblUser.ForeColor = Color.White;
            lblUser.Dock = DockStyle.Right;
            lblUser.Padding = new Padding(0, 0, 20, 0);
            lblUser.TextAlign = ContentAlignment.MiddleRight;
            lblUser.Width = 150;
            header.Controls.Add(lblUser);
            header.Controls.Add(lblTitle);
            this.Controls.Add(header);
        }

        private void CreateContentPanel()
        {
            contentPanel = new Panel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.BackColor = Color.FromArgb(7, 11, 24);
            contentPanel.AutoScroll = true;
            this.Controls.Add(contentPanel);
        }

        private void NavButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int index = (int)btn.Tag;
            switch (index)
            {
                case 0: LoadDashboard(); break;
                case 1: LoadEmployees(); break;
                case 2: LoadSickLeaves(); break;
                case 3: LoadReports(); break;
                case 4: LoadTrash(); break;
                case 5: LoadAuditLog(); break;
                case 6: LoadUsers(); break;
                case 7: LoadDepartments(); break;
                case 8: LoadSettings(); break;
                case 9: LoadBackupRestore(); break;
                case 10: Logout(); break;
            }
        }

        private void LoadDashboard()
        {
            ClearContent();
            DashboardControl dash = new DashboardControl();
            dash.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(dash);
            currentPage = dash;
        }

        private void LoadEmployees()
        {
            ClearContent();
            frmEmployees frm = new frmEmployees();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadSickLeaves()
        {
            ClearContent();
            frmSickLeaves frm = new frmSickLeaves();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadReports()
        {
            ClearContent();
            frmReports frm = new frmReports();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadTrash()
        {
            ClearContent();
            frmTrash frm = new frmTrash();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadAuditLog()
        {
            ClearContent();
            frmAuditLog frm = new frmAuditLog();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadUsers()
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin))
            {
                MessageBox.Show("غير مصرح لك بالوصول إلى إدارة المستخدمين.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            ClearContent();
            frmUsers frm = new frmUsers();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadDepartments()
        {
            ClearContent();
            frmDepartments frm = new frmDepartments();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadSettings()
        {
            ClearContent();
            frmSettings frm = new frmSettings();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void LoadBackupRestore()
        {
            ClearContent();
            frmBackupRestore frm = new frmBackupRestore();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            contentPanel.Controls.Add(frm);
            frm.Show();
            currentPage = frm;
        }

        private void Logout()
        {
            AuditHelper.LogLogout(GlobalState.CurrentUser.Username);
            GlobalState.CurrentUser = null;
            this.DialogResult = DialogResult.Abort;
            this.Close();
        }

        private void ClearContent()
        {
            if (currentPage != null)
            {
                contentPanel.Controls.Remove(currentPage);
                currentPage.Dispose();
                currentPage = null;
            }
            foreach (Control ctrl in contentPanel.Controls)
                ctrl.Dispose();
            contentPanel.Controls.Clear();
        }

        private void CheckPermissions()
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin))
                btnUsers.Visible = false;
            if (!SecurityHelper.CanEdit())
            {
                // إخفاء أزرار الإضافة في الأماكن المناسبة
            }
        }
    }
}