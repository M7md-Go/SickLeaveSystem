using System;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmUserDetail : Form
    {
        private int userId = 0;
        private bool isEdit = false;
        private TextBox txtUsername, txtPassword, txtConfirm;
        private ComboBox cmbRole;
        private CheckBox chkActive;
        private Button btnSave, btnCancel;

        public frmUserDetail(int id = 0, string username = "", string role = "", bool isActive = true)
        {
            userId = id;
            isEdit = id > 0;
            InitializeComponent();
            if (isEdit)
            {
                txtUsername.Text = username;
                txtUsername.ReadOnly = true;
                cmbRole.SelectedItem = role == Constants.RoleAdmin ? "مشرف عام" : (role == Constants.RoleHR ? "موارد بشرية" : "مشاهد");
                chkActive.Checked = isActive;
                this.Text = "تعديل مستخدم";
            }
            else
                this.Text = "إضافة مستخدم جديد";
        }

        private void InitializeComponent()
        {
            this.Text = isEdit ? "تعديل مستخدم" : "إضافة مستخدم";
            this.Size = new Size(450, 320);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(13, 24, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            TableLayoutPanel tlp = new TableLayoutPanel();
            tlp.Dock = DockStyle.Fill;
            tlp.ColumnCount = 2;
            tlp.RowCount = 5;
            tlp.Padding = new Padding(15);
            tlp.BackColor = Color.FromArgb(13, 24, 40);

            // اسم المستخدم
            Label lblUser = new Label();
            lblUser.Text = "اسم المستخدم:";
            lblUser.ForeColor = Color.White;
            txtUsername = new TextBox();
            txtUsername.BackColor = Color.FromArgb(22, 30, 50);
            txtUsername.ForeColor = Color.White;
            tlp.Controls.Add(lblUser, 0, 0);
            tlp.Controls.Add(txtUsername, 1, 0);

            // كلمة المرور
            Label lblPass = new Label();
            lblPass.Text = "كلمة المرور:";
            lblPass.ForeColor = Color.White;
            txtPassword = new TextBox();
            txtPassword.PasswordChar = '*';
            txtPassword.BackColor = Color.FromArgb(22, 30, 50);
            txtPassword.ForeColor = Color.White;
            tlp.Controls.Add(lblPass, 0, 1);
            tlp.Controls.Add(txtPassword, 1, 1);

            // تأكيد كلمة المرور
            Label lblConfirm = new Label();
            lblConfirm.Text = "تأكيد كلمة المرور:";
            lblConfirm.ForeColor = Color.White;
            txtConfirm = new TextBox();
            txtConfirm.PasswordChar = '*';
            txtConfirm.BackColor = Color.FromArgb(22, 30, 50);
            txtConfirm.ForeColor = Color.White;
            tlp.Controls.Add(lblConfirm, 0, 2);
            tlp.Controls.Add(txtConfirm, 1, 2);

            // الصلاحية
            Label lblRole = new Label();
            lblRole.Text = "الصلاحية:";
            lblRole.ForeColor = Color.White;
            cmbRole = new ComboBox();
            cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRole.Items.AddRange(new string[] { "مشاهد", "موارد بشرية", "مشرف عام" });
            cmbRole.SelectedIndex = 0;
            cmbRole.BackColor = Color.FromArgb(22, 30, 50);
            cmbRole.ForeColor = Color.White;
            tlp.Controls.Add(lblRole, 0, 3);
            tlp.Controls.Add(cmbRole, 1, 3);

            // الحالة (نشط)
            Label lblActive = new Label();
            lblActive.Text = "الحالة:";
            lblActive.ForeColor = Color.White;
            chkActive = new CheckBox();
            chkActive.Text = "نشط";
            chkActive.ForeColor = Color.White;
            chkActive.Checked = true;
            tlp.Controls.Add(lblActive, 0, 4);
            tlp.Controls.Add(chkActive, 1, 4);

            this.Controls.Add(tlp);

            // لوحة الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(8, 15, 30);

            btnSave = new Button();
            btnSave.Text = "💾 حفظ";
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.BackColor = Color.FromArgb(16, 201, 127);
            btnSave.ForeColor = Color.Black;
            btnSave.Size = new Size(100, 35);
            btnSave.Location = new Point(100, 8);
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button();
            btnCancel.Text = "إلغاء";
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.BackColor = Color.FromArgb(240, 79, 100);
            btnCancel.ForeColor = Color.White;
            btnCancel.Size = new Size(100, 35);
            btnCancel.Location = new Point(210, 8);
            btnCancel.Click += (s, e) => this.Close();

            buttonPanel.Controls.Add(btnSave);
            buttonPanel.Controls.Add(btnCancel);
            this.Controls.Add(buttonPanel);
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirm = txtConfirm.Text;
            string roleText = cmbRole.SelectedItem.ToString();
            string role = roleText == "مشرف عام" ? Constants.RoleAdmin : (roleText == "موارد بشرية" ? Constants.RoleHR : Constants.RoleViewer);
            bool isActive = chkActive.Checked;

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("اسم المستخدم مطلوب.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!isEdit)
            {
                if (string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("كلمة المرور مطلوبة للمستخدم الجديد.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (password != confirm)
                {
                    MessageBox.Show("كلمتا المرور غير متطابقتين.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (password.Length < 6)
                {
                    MessageBox.Show("كلمة المرور يجب أن تكون 6 أحرف على الأقل.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string salt = SecurityHelper.GenerateSalt();
                string hash = SecurityHelper.HashPassword(password, salt);
                bool success = BusinessLogic.AddUser(username, hash, salt, role);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionInsert, Constants.TableUsers, 0, $"إضافة مستخدم جديد: {username}");
                    MessageBox.Show("تمت إضافة المستخدم بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشلت إضافة المستخدم. قد يكون اسم المستخدم مكرراً.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string newHash = null, newSalt = null;
                if (!string.IsNullOrEmpty(password))
                {
                    if (password != confirm)
                    {
                        MessageBox.Show("كلمتا المرور غير متطابقتين.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    if (password.Length < 6)
                    {
                        MessageBox.Show("كلمة المرور يجب أن تكون 6 أحرف على الأقل.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    newSalt = SecurityHelper.GenerateSalt();
                    newHash = SecurityHelper.HashPassword(password, newSalt);
                }
                bool success = BusinessLogic.UpdateUser(userId, role, isActive, newHash, newSalt);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionUpdate, Constants.TableUsers, userId, $"تعديل مستخدم: {username}");
                    MessageBox.Show("تم تعديل بيانات المستخدم بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشل تعديل المستخدم.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}