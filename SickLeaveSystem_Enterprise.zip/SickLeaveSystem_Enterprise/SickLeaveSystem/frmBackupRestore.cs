using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmBackupRestore : Form
    {
        private ListBox lstBackups;
        private Button btnCreateBackup, btnRestore, btnDeleteBackup, btnRefresh;
        private Label lblInfo;

        public frmBackupRestore()
        {
            InitializeComponent();
            LoadBackupList();
        }

        private void InitializeComponent()
        {
            this.Text = "النسخ الاحتياطي والاستعادة";
            this.Size = new Size(600, 450);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(7, 11, 24);

            // لوحة المعلومات
            Panel infoPanel = new Panel();
            infoPanel.Dock = DockStyle.Top;
            infoPanel.Height = 60;
            infoPanel.BackColor = Color.FromArgb(13, 24, 40);
            lblInfo = new Label();
            lblInfo.Text = "قائمة النسخ الاحتياطية المتاحة";
            lblInfo.ForeColor = Color.White;
            lblInfo.Font = new Font("Cairo", 10, FontStyle.Bold);
            lblInfo.Dock = DockStyle.Fill;
            lblInfo.TextAlign = ContentAlignment.MiddleCenter;
            infoPanel.Controls.Add(lblInfo);

            // قائمة النسخ
            lstBackups = new ListBox();
            lstBackups.Dock = DockStyle.Fill;
            lstBackups.BackColor = Color.FromArgb(22, 30, 50);
            lstBackups.ForeColor = Color.White;
            lstBackups.Font = new Font("Cairo", 10);
            lstBackups.DrawMode = DrawMode.OwnerDrawFixed;
            lstBackups.DrawItem += LstBackups_DrawItem;

            // شريط الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 55;
            buttonPanel.BackColor = Color.FromArgb(13, 24, 40);
            buttonPanel.Padding = new Padding(8);

            btnCreateBackup = new Button();
            btnCreateBackup.Text = "💾 إنشاء نسخة احتياطية";
            btnCreateBackup.FlatStyle = FlatStyle.Flat;
            btnCreateBackup.BackColor = Color.FromArgb(16, 201, 127);
            btnCreateBackup.ForeColor = Color.Black;
            btnCreateBackup.Size = new Size(160, 35);
            btnCreateBackup.Location = new Point(8, 8);
            btnCreateBackup.Click += BtnCreateBackup_Click;

            btnRestore = new Button();
            btnRestore.Text = "♻️ استعادة";
            btnRestore.FlatStyle = FlatStyle.Flat;
            btnRestore.BackColor = Color.FromArgb(79, 142, 247);
            btnRestore.ForeColor = Color.White;
            btnRestore.Size = new Size(100, 35);
            btnRestore.Location = new Point(178, 8);
            btnRestore.Click += BtnRestore_Click;

            btnDeleteBackup = new Button();
            btnDeleteBackup.Text = "🗑 حذف";
            btnDeleteBackup.FlatStyle = FlatStyle.Flat;
            btnDeleteBackup.BackColor = Color.FromArgb(240, 79, 100);
            btnDeleteBackup.ForeColor = Color.White;
            btnDeleteBackup.Size = new Size(100, 35);
            btnDeleteBackup.Location = new Point(288, 8);
            btnDeleteBackup.Click += BtnDeleteBackup_Click;

            btnRefresh = new Button();
            btnRefresh.Text = "🔄 تحديث";
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.BackColor = Color.FromArgb(245, 158, 11);
            btnRefresh.ForeColor = Color.Black;
            btnRefresh.Size = new Size(100, 35);
            btnRefresh.Location = new Point(398, 8);
            btnRefresh.Click += BtnRefresh_Click;

            buttonPanel.Controls.Add(btnCreateBackup);
            buttonPanel.Controls.Add(btnRestore);
            buttonPanel.Controls.Add(btnDeleteBackup);
            buttonPanel.Controls.Add(btnRefresh);

            this.Controls.Add(lstBackups);
            this.Controls.Add(buttonPanel);
            this.Controls.Add(infoPanel);
        }

        private void LoadBackupList()
        {
            lstBackups.Items.Clear();
            string[] backups = BackupHelper.GetBackupFiles();
            foreach (string backup in backups)
            {
                FileInfo fi = new FileInfo(backup);
                string size = (fi.Length / 1024).ToString() + " KB";
                string date = fi.CreationTime.ToString("yyyy-MM-dd HH:mm:ss");
                lstBackups.Items.Add($"{fi.Name} | {date} | {size}");
            }
            if (backups.Length == 0)
                lstBackups.Items.Add("لا توجد نسخ احتياطية");
        }

        private void LstBackups_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            e.DrawBackground();
            Brush brush = (e.State & DrawItemState.Selected) == DrawItemState.Selected ? Brushes.Yellow : Brushes.White;
            e.Graphics.DrawString(lstBackups.Items[e.Index].ToString(), e.Font, brush, e.Bounds);
            e.DrawFocusRectangle();
        }

        private string GetSelectedBackupPath()
        {
            if (lstBackups.SelectedItem == null || lstBackups.SelectedItem.ToString() == "لا توجد نسخ احتياطية")
                return null;
            string selected = lstBackups.SelectedItem.ToString();
            string fileName = selected.Split('|')[0].Trim();
            string fullPath = Path.Combine(GlobalState.BackupPath, fileName);
            return File.Exists(fullPath) ? fullPath : null;
        }

        private void BtnCreateBackup_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بإنشاء نسخة احتياطية.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (BackupHelper.CreateBackup())
            {
                LoadBackupList();
                MessageBox.Show("تم إنشاء النسخة الاحتياطية بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnRestore_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.HasAccess(Constants.RoleAdmin))
            {
                MessageBox.Show("غير مصرح لك باستعادة قاعدة البيانات.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string backupPath = GetSelectedBackupPath();
            if (backupPath == null)
            {
                MessageBox.Show("الرجاء اختيار نسخة احتياطية أولاً.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("تحذير: استعادة قاعدة البيانات ستحل محل البيانات الحالية بالكامل. هل أنت متأكد؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                if (BackupHelper.RestoreBackup(backupPath))
                {
                    MessageBox.Show("تمت استعادة قاعدة البيانات. سيتم إعادة تشغيل التطبيق.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Application.Restart();
                }
            }
        }

        private void BtnDeleteBackup_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanDelete()) return;
            string backupPath = GetSelectedBackupPath();
            if (backupPath == null) return;
            if (MessageBox.Show($"هل أنت متأكد من حذف النسخة الاحتياطية '{Path.GetFileName(backupPath)}'؟", "تأكيد", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                File.Delete(backupPath);
                LoadBackupList();
            }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadBackupList();
        }
    }
}