using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using SickLeaveSystem.Classes;

namespace SickLeaveSystem
{
    public partial class frmEmployeeDetail : Form
    {
        private int employeeId = 0;
        private bool readOnly = false;
        private TextBox txtCode, txtName, txtJob, txtPhone, txtEmail, txtAddress, txtNationalID, txtNotes;
        private ComboBox cmbDepartment, cmbStatus;
        private DateTimePicker dtpHireDate, dtpStartDate, dtpBirth;
        private Button btnSave, btnCancel;

        public frmEmployeeDetail(int id = 0, bool readOnlyMode = false)
        {
            employeeId = id;
            readOnly = readOnlyMode;
            InitializeComponent();
            LoadDepartments();
            LoadStatuses();
            if (employeeId > 0)
                LoadEmployeeData();
            if (readOnly)
                SetReadOnly();
        }

        private void InitializeComponent()
        {
            this.Text = employeeId == 0 ? "إضافة موظف جديد" : "تعديل بيانات موظف";
            this.Size = new Size(700, 550);
            this.StartPosition = FormStartPosition.CenterParent;
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.BackColor = Color.FromArgb(13, 24, 40);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            TableLayoutPanel tlp = new TableLayoutPanel();
            tlp.Dock = DockStyle.Fill;
            tlp.ColumnCount = 2;
            tlp.RowCount = 12;
            tlp.Padding = new Padding(15);
            tlp.BackColor = Color.FromArgb(13, 24, 40);

            // الصفوف
            AddLabelAndControl(tlp, 0, "الكود:", out txtCode);
            AddLabelAndControl(tlp, 1, "الاسم الكامل:", out txtName);
            AddLabelAndControl(tlp, 2, "الوظيفة:", out txtJob);
            AddLabelAndControl(tlp, 3, "القسم:", out cmbDepartment, true);
            AddLabelAndControl(tlp, 4, "تاريخ التعيين:", out dtpHireDate, false);
            AddLabelAndControl(tlp, 5, "تاريخ استلام العمل:", out dtpStartDate, false);
            AddLabelAndControl(tlp, 6, "تاريخ الميلاد:", out dtpBirth, false);
            AddLabelAndControl(tlp, 7, "الرقم القومي:", out txtNationalID);
            AddLabelAndControl(tlp, 8, "الهاتف:", out txtPhone);
            AddLabelAndControl(tlp, 9, "البريد الإلكتروني:", out txtEmail);
            AddLabelAndControl(tlp, 10, "العنوان:", out txtAddress);
            AddLabelAndControl(tlp, 11, "ملاحظات:", out txtNotes);

            this.Controls.Add(tlp);

            // لوحة الأزرار
            Panel buttonPanel = new Panel();
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Height = 50;
            buttonPanel.BackColor = Color.FromArgb(8, 15, 30);

            btnSave = new Button();
            btnSave.Text = "💾 حفظ";
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.BackColor = Color.FromArgb(16, 201, 127);
            btnSave.ForeColor = Color.Black;
            btnSave.Size = new Size(100, 35);
            btnSave.Location = new Point(150, 8);
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button();
            btnCancel.Text = "إلغاء";
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.BackColor = Color.FromArgb(240, 79, 100);
            btnCancel.ForeColor = Color.White;
            btnCancel.Size = new Size(100, 35);
            btnCancel.Location = new Point(260, 8);
            btnCancel.Click += (s, e) => this.Close();

            buttonPanel.Controls.Add(btnSave);
            buttonPanel.Controls.Add(btnCancel);
            this.Controls.Add(buttonPanel);
        }

        private void AddLabelAndControl(TableLayoutPanel tlp, int row, string labelText, out TextBox textBox, bool isCombo = false)
        {
            Label lbl = new Label();
            lbl.Text = labelText;
            lbl.ForeColor = Color.White;
            lbl.TextAlign = ContentAlignment.MiddleRight;
            lbl.Dock = DockStyle.Fill;
            lbl.Font = new Font("Cairo", 10);

            if (isCombo)
            {
                ComboBox combo = new ComboBox();
                combo.DropDownStyle = ComboBoxStyle.DropDownList;
                combo.BackColor = Color.FromArgb(22, 30, 50);
                combo.ForeColor = Color.White;
                combo.Dock = DockStyle.Fill;
                tlp.Controls.Add(lbl, 0, row);
                tlp.Controls.Add(combo, 1, row);
                textBox = null;
                cmbDepartment = combo;
                return;
            }

            TextBox txt = new TextBox();
            txt.BackColor = Color.FromArgb(22, 30, 50);
            txt.ForeColor = Color.White;
            txt.Dock = DockStyle.Fill;
            tlp.Controls.Add(lbl, 0, row);
            tlp.Controls.Add(txt, 1, row);
            textBox = txt;
        }

        private void AddLabelAndControl(TableLayoutPanel tlp, int row, string labelText, out DateTimePicker dtp, bool isDate = true)
        {
            Label lbl = new Label();
            lbl.Text = labelText;
            lbl.ForeColor = Color.White;
            lbl.TextAlign = ContentAlignment.MiddleRight;
            lbl.Dock = DockStyle.Fill;
            dtp = new DateTimePicker();
            dtp.Format = DateTimePickerFormat.Short;
            dtp.BackColor = Color.FromArgb(22, 30, 50);
            dtp.ForeColor = Color.White;
            dtp.Dock = DockStyle.Fill;
            tlp.Controls.Add(lbl, 0, row);
            tlp.Controls.Add(dtp, 1, row);
        }

        private void LoadDepartments()
        {
            DataTable dt = BusinessLogic.GetAllDepartments();
            cmbDepartment.DataSource = dt;
            cmbDepartment.DisplayMember = "Name";
            cmbDepartment.ValueMember = "ID";
        }

        private void LoadStatuses()
        {
            // نضيف حقل الحالة الوظيفية (يمكن إضافته كصف منفصل)
            // لكن في التصميم أعلاه لم نضف الحالة، لذا نضيفها الآن بشكل منفصل
            // سنقوم بإضافة صف إضافي للحالة
            TableLayoutPanel tlp = this.Controls[0] as TableLayoutPanel;
            if (tlp != null && tlp.RowCount == 12)
            {
                tlp.RowCount = 13;
                Label lblStatus = new Label();
                lblStatus.Text = "الحالة الوظيفية:";
                lblStatus.ForeColor = Color.White;
                lblStatus.TextAlign = ContentAlignment.MiddleRight;
                cmbStatus = new ComboBox();
                cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;
                cmbStatus.BackColor = Color.FromArgb(22, 30, 50);
                cmbStatus.ForeColor = Color.White;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");
                dt.Columns.Add("Text");
                dt.Rows.Add(Constants.EmployeeStatusActive, "نشط");
                dt.Rows.Add(Constants.EmployeeStatusInactive, "غير نشط");
                dt.Rows.Add(Constants.EmployeeStatusOnLeave, "في إجازة");
                cmbStatus.DataSource = dt;
                cmbStatus.DisplayMember = "Text";
                cmbStatus.ValueMember = "Value";
                tlp.Controls.Add(lblStatus, 0, 12);
                tlp.Controls.Add(cmbStatus, 1, 12);
            }
        }

        private void LoadEmployeeData()
        {
            DataTable dt = DatabaseManager.ExecuteQuery("SELECT * FROM Employees WHERE ID=?", DatabaseManager.CreateParameter("@id", employeeId));
            if (dt.Rows.Count > 0)
            {
                DataRow r = dt.Rows[0];
                txtCode.Text = r["Code"].ToString();
                txtName.Text = r["Name"].ToString();
                txtJob.Text = r["JobTitle"].ToString();
                if (r["DepartmentID"] != DBNull.Value)
                    cmbDepartment.SelectedValue = r["DepartmentID"];
                dtpHireDate.Value = r["HireDate"] == DBNull.Value ? DateTime.Now : Convert.ToDateTime(r["HireDate"]);
                dtpStartDate.Value = r["StartDate"] == DBNull.Value ? DateTime.Now : Convert.ToDateTime(r["StartDate"]);
                dtpBirth.Value = r["BirthDate"] == DBNull.Value ? DateTime.Now.AddYears(-30) : Convert.ToDateTime(r["BirthDate"]);
                txtNationalID.Text = r["NationalID"].ToString();
                txtPhone.Text = r["Phone"].ToString();
                txtEmail.Text = r["Email"].ToString();
                txtAddress.Text = r["Address"].ToString();
                txtNotes.Text = r["Notes"].ToString();
                if (cmbStatus != null)
                    cmbStatus.SelectedValue = r["Status"].ToString();
            }
        }

        private void SetReadOnly()
        {
            readOnly = true;
            btnSave.Visible = false;
            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is TextBox) (ctrl as TextBox).ReadOnly = true;
                if (ctrl is ComboBox) (ctrl as ComboBox).Enabled = false;
                if (ctrl is DateTimePicker) (ctrl as DateTimePicker).Enabled = false;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!SecurityHelper.CanEdit())
            {
                MessageBox.Show("غير مصرح لك بالتعديل.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCode.Text) || string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("الكود والاسم مطلوبان.", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            EmployeeModel emp = new EmployeeModel();
            emp.Code = txtCode.Text.Trim();
            emp.Name = txtName.Text.Trim();
            emp.JobTitle = txtJob.Text.Trim();
            emp.DepartmentID = cmbDepartment.SelectedValue != null ? Convert.ToInt32(cmbDepartment.SelectedValue) : (int?)null;
            emp.HireDate = dtpHireDate.Value;
            emp.StartDate = dtpStartDate.Value;
            emp.BirthDate = dtpBirth.Value;
            emp.NationalID = txtNationalID.Text.Trim();
            emp.Status = cmbStatus.SelectedValue.ToString();
            emp.Phone = txtPhone.Text.Trim();
            emp.Email = txtEmail.Text.Trim();
            emp.Address = txtAddress.Text.Trim();
            emp.Notes = txtNotes.Text.Trim();

            if (employeeId == 0)
            {
                int newId = BusinessLogic.AddEmployee(emp);
                if (newId > 0)
                {
                    AuditHelper.Log(Constants.AuditActionInsert, Constants.TableEmployees, newId, $"إضافة موظف: {emp.Name}");
                    MessageBox.Show("تمت إضافة الموظف بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشلت إضافة الموظف. قد يكون الكود مكرراً.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                emp.ID = employeeId;
                bool success = BusinessLogic.UpdateEmployee(emp);
                if (success)
                {
                    AuditHelper.Log(Constants.AuditActionUpdate, Constants.TableEmployees, employeeId, $"تعديل موظف: {emp.Name}");
                    MessageBox.Show("تم تعديل بيانات الموظف بنجاح.", "تم", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                    MessageBox.Show("فشل تعديل بيانات الموظف.", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}